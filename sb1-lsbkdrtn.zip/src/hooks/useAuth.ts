// [AI Generated] Data: 04/01/2025
// Descrição: Hook para gerenciamento de autenticação - Corrigido erro após cadastro
// Gerado por: Cursor AI
// Versão: React 18.3.1, TypeScript 5.5.3
// AI_GENERATED_CODE_START
import { useState, useEffect } from 'react';
import { UserProfile } from './useProfile';

interface AuthState {
  isAuthenticated: boolean;
  userProfile: UserProfile | null;
  userEmail: string | null;
}

interface RegisteredUser {
  email: string;
  password: string;
  profile: UserProfile;
  name: string;
}

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    userProfile: null,
    userEmail: null
  });

  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUser[]>([]);

  // Credenciais válidas para cada perfil
  const validCredentials = {
    normal: { email: 'praticante@synthonia.bio', password: 'praticante123' },
    athlete: { email: 'atleta@synthonia.bio', password: 'atleta123' },
    coach: { email: 'fisioterapeuta@synthonia.bio', password: 'fisioterapeuta123' }
  };

  useEffect(() => {
    // Verificar se há sessão salva no localStorage
    const savedAuth = localStorage.getItem('synthonia_auth');
    const savedUsers = localStorage.getItem('synthonia_registered_users');
    
    if (savedAuth) {
      try {
        const parsedAuth = JSON.parse(savedAuth);
        setAuthState(parsedAuth);
      } catch (error) {
        console.error('Erro ao carregar sessão:', error);
        localStorage.removeItem('synthonia_auth');
      }
    }
    
    if (savedUsers) {
      try {
        const parsedUsers = JSON.parse(savedUsers);
        setRegisteredUsers(parsedUsers);
      } catch (error) {
        console.error('Erro ao carregar usuários registrados:', error);
        localStorage.removeItem('synthonia_registered_users');
      }
    }
  }, []);

  const login = (profile: UserProfile, credentials: { email: string; password: string }) => {
    console.log('Tentativa de login:', { profile, email: credentials.email });
    console.log('Usuários registrados:', registeredUsers);
    
    // Verificar credenciais padrão
    const defaultCreds = validCredentials[profile];
    const isDefaultUser = credentials.email === defaultCreds.email && credentials.password === defaultCreds.password;
    
    // Verificar usuários registrados
    const registeredUser = registeredUsers.find(user => 
      user.email.toLowerCase() === credentials.email.toLowerCase() && 
      user.password === credentials.password && 
      user.profile === profile
    );
    
    console.log('Usuário padrão encontrado:', isDefaultUser);
    console.log('Usuário registrado encontrado:', !!registeredUser);
    
    if (!isDefaultUser && !registeredUser) {
      console.log('Credenciais inválidas');
      throw new Error('Email ou senha incorretos');
    }
    
    const newAuthState = {
      isAuthenticated: true,
      userProfile: profile,
      userEmail: credentials.email
    };
    
    console.log('Login bem-sucedido:', newAuthState);
    setAuthState(newAuthState);
    localStorage.setItem('synthonia_auth', JSON.stringify(newAuthState));
  };

  const register = (profile: UserProfile, userData: { email: string; password: string; name: string }) => {
    console.log('Tentativa de registro:', { profile, email: userData.email, name: userData.name });
    
    // Verificar se email já existe (case insensitive)
    const emailExists = registeredUsers.some(user => 
      user.email.toLowerCase() === userData.email.toLowerCase()
    );
    
    const isDefaultEmail = Object.values(validCredentials).some(cred => 
      cred.email.toLowerCase() === userData.email.toLowerCase()
    );
    
    if (emailExists || isDefaultEmail) {
      console.log('Email já existe');
      throw new Error('Este email já está em uso');
    }
    
    const newUser: RegisteredUser = {
      email: userData.email,
      password: userData.password,
      profile: profile,
      name: userData.name
    };
    
    const updatedUsers = [...registeredUsers, newUser];
    console.log('Novo usuário registrado:', newUser);
    console.log('Lista atualizada de usuários:', updatedUsers);
    
    setRegisteredUsers(updatedUsers);
    localStorage.setItem('synthonia_registered_users', JSON.stringify(updatedUsers));
    
    console.log('Registro concluído com sucesso');
  };

  const logout = () => {
    console.log('Fazendo logout');
    const newAuthState = {
      isAuthenticated: false,
      userProfile: null,
      userEmail: null
    };
    
    setAuthState(newAuthState);
    localStorage.removeItem('synthonia_auth');
  };

  return {
    ...authState,
    login,
    register,
    logout,
    registeredUsers // Expor para debug se necessário
  };
};
// AI_GENERATED_CODE_END