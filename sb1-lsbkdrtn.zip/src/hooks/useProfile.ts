import { useState, useEffect } from 'react';

export type UserProfile = 'normal' | 'athlete' | 'coach';

export interface ProfileData {
  id: string;
  type: UserProfile;
  name: string;
  email: string;
  coachId?: string;
  athletes?: string[];
  createdAt: string;
}

export const useProfile = () => {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simular carregamento do perfil
    const loadProfile = async () => {
      try {
        // Aqui você faria a chamada para o Supabase
        const mockProfile: ProfileData = {
          id: '1',
          type: 'normal',
          name: 'João Silva',
          email: 'joao@email.com',
          createdAt: new Date().toISOString()
        };
        
        setProfile(mockProfile);
      } catch (error) {
        console.error('Erro ao carregar perfil:', error);
      } finally {
        setLoading(false);
      }
    };

    loadProfile();
  }, []);

  const updateProfile = async (newProfile: Partial<ProfileData>) => {
    if (!profile) return;
    
    try {
      // Aqui você faria a atualização no Supabase
      setProfile({ ...profile, ...newProfile });
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
    }
  };

  return {
    profile,
    loading,
    updateProfile,
    isNormal: profile?.type === 'normal',
    isAthlete: profile?.type === 'athlete',
    isCoach: profile?.type === 'coach'
  };
};