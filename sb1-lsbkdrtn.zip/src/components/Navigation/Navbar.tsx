// [AI Generated] Data: 04/01/2025
// Descrição: Barra de navegação responsiva para o dashboard
// Gerado por: Cursor AI
// Versão: React 18.3.1, TypeScript 5.5.3
// AI_GENERATED_CODE_START
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Home, 
  Heart, 
  Activity, 
  Brain, 
  BarChart3, 
  LogOut, 
  Menu, 
  X,
  User,
  Trophy,
  Users,
  ClipboardList
} from 'lucide-react';
import { UserProfile } from '../../hooks/useProfile';

interface NavbarProps {
  userProfile: UserProfile;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ userProfile, onLogout }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const getProfileIcon = () => {
    switch (userProfile) {
      case 'coach': return Users;
      case 'athlete': return Trophy;
      default: return User;
    }
  };

  const getProfileTitle = () => {
    switch (userProfile) {
      case 'coach': return 'Treinador';
      case 'athlete': return 'Atleta';
      default: return 'Praticante';
    }
  };

  const getProfileColor = () => {
    switch (userProfile) {
      case 'coach': return 'text-violet-600 bg-violet-100';
      case 'athlete': return 'text-amber-600 bg-amber-100';
      default: return 'text-emerald-600 bg-emerald-100';
    }
  };

  const navigationItems = [
    { path: '/', icon: Home, label: 'Dashboard', color: 'text-blue-600' },
    { path: '/recovery', icon: Heart, label: 'Recuperação', color: 'text-green-600' },
    { path: '/training', icon: Activity, label: 'Treino', color: 'text-orange-600' },
    { path: '/rehabilitation', icon: Brain, label: 'Reabilitação', color: 'text-red-600' },
    { path: '/ai-analysis', icon: Brain, label: 'Análise IA', color: 'text-purple-600' },
    { path: '/analytics', icon: BarChart3, label: 'Analytics', color: 'text-cyan-600' },
  ];

  const ProfileIcon = getProfileIcon();

  const isActivePath = (path: string) => {
    return location.pathname === path;
  };

  const handleNavigation = (path: string) => {
    navigate(path);
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      {/* Desktop Navbar */}
      <nav className="hidden md:flex bg-white shadow-lg border-b border-gray-200 px-4 py-3">
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
          {/* Logo e Título */}
          <div className="flex items-center space-x-4">
            <img 
              src="/logo copy.png" 
              alt="Synthonia Logo" 
              className="h-10 w-10 object-contain"
              style={{ aspectRatio: '1/1' }}
            />
            <div>
              <h1 className="text-lg font-bold text-gray-900">
                SynthonIA Analytics
              </h1>
              <p className="text-xs text-gray-500">
                Sistema Neurofisiológico
              </p>
            </div>
          </div>

          {/* Navigation Items */}
          <div className="flex items-center space-x-1">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = isActivePath(item.path);
              
              return (
                <button
                  key={item.path}
                  onClick={() => handleNavigation(item.path)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 border-2 border-blue-200'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${isActive ? 'bg-blue-100' : 'bg-gray-100'}`}>
                    <Icon className={`h-3 w-3 ${isActive ? 'text-blue-600' : item.color}`} />
                  </div>
                  <span className="text-sm font-medium">{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Profile e Logout */}
          <div className="flex items-center space-x-4">
            <div className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${getProfileColor()}`}>
              <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center">
                <ProfileIcon className="h-3 w-3" />
              </div>
              <span className="text-sm font-medium">{getProfileTitle()}</span>
            </div>
            
            <button
              onClick={onLogout}
              className="flex items-center space-x-2 px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              title="Sair"
            >
              <div className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center">
                <LogOut className="h-3 w-3" />
              </div>
              <span className="text-sm">Sair</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Navbar */}
      <nav className="md:hidden bg-white shadow-lg border-b border-gray-200">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Logo e Menu Button */}
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 rounded-lg text-gray-600 hover:bg-gray-100"
              >
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
              
              <div className="flex items-center space-x-2">
                <img 
                  src="/logo copy.png" 
                  alt="Synthonia Logo" 
                  className="h-8 w-8 object-contain"
                  style={{ aspectRatio: '1/1' }}
                />
                <div>
                  <h1 className="text-sm font-bold text-gray-900">
                    SynthonIA
                  </h1>
                </div>
              </div>
            </div>

            {/* Profile Badge */}
            <div className={`flex items-center space-x-2 px-2 py-1 rounded-lg ${getProfileColor()}`}>
              <div className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center">
                <ProfileIcon className="h-3 w-3" />
              </div>
              <span className="text-xs font-medium">{getProfileTitle()}</span>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="mt-4 pb-4 border-t border-gray-200">
              <div className="pt-4 space-y-2">
                {navigationItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = isActivePath(item.path);
                  
                  return (
                    <button
                      key={item.path}
                      onClick={() => handleNavigation(item.path)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                        isActive
                          ? 'bg-blue-50 text-blue-700 border-2 border-blue-200'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isActive ? 'bg-blue-100' : 'bg-gray-100'}`}>
                        <Icon className={`h-4 w-4 ${isActive ? 'text-blue-600' : item.color}`} />
                      </div>
                      <span className="font-medium">{item.label}</span>
                    </button>
                  );
                })}
                
                {/* Logout Button */}
                <button
                  onClick={onLogout}
                  className="w-full flex items-center space-x-3 px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors mt-4"
                >
                  <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                    <LogOut className="h-4 w-4" />
                  </div>
                  <span className="font-medium">Sair</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>
    </>
  );
};

export default Navbar;
// AI_GENERATED_CODE_END