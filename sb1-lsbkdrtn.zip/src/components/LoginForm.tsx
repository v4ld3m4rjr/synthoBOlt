// [AI Generated] Data: 04/01/2025
// Descrição: Componente de login com cadastro e recuperação de senha
// Gerado por: Cursor AI
// Versão: React 18.3.1, TypeScript 5.5.3
// AI_GENERATED_CODE_START
import React, { useState } from 'react';
import { User, Trophy, Users, Eye, EyeOff, Lock, Mail, UserPlus, ArrowLeft } from 'lucide-react';
import { UserProfile } from '../hooks/useProfile';

interface LoginFormProps {
  onLogin: (profile: UserProfile, credentials: { email: string; password: string }) => void;
  onRegister: (profile: UserProfile, userData: { email: string; password: string; name: string }) => void;
}

type FormMode = 'profile-select' | 'login' | 'register' | 'forgot-password';

const LoginForm: React.FC<LoginFormProps> = ({ onLogin, onRegister }) => {
  const [mode, setMode] = useState<FormMode>('profile-select');
  const [selectedProfile, setSelectedProfile] = useState<UserProfile | null>(null);
  const [credentials, setCredentials] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    name: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const profiles = [
    {
      type: 'normal' as UserProfile,
      title: 'Praticante',
      description: 'Acesso completo para monitoramento pessoal',
      icon: User,
      color: 'from-emerald-600 to-teal-700',
      bgColor: 'bg-gradient-to-br from-emerald-200 to-teal-200',
      borderColor: 'border-emerald-400 hover:border-emerald-500',
      defaultCredentials: { email: 'praticante@synthonia.bio', password: 'praticante123' }
    },
    {
      type: 'athlete' as UserProfile,
      title: 'Atleta',
      description: 'Funcionalidades + conexão com treinador',
      icon: Trophy,
      color: 'from-amber-600 to-orange-700',
      bgColor: 'bg-gradient-to-br from-amber-200 to-orange-200',
      borderColor: 'border-amber-400 hover:border-amber-500',
      defaultCredentials: { email: 'atleta@synthonia.bio', password: 'atleta123' }
    },
    {
      type: 'coach' as UserProfile,
      title: 'Treinador/Fisioterapeuta',
      description: 'Gestão e análise de atletas e equipes',
      icon: Users,
      color: 'from-violet-600 to-purple-700',
      bgColor: 'bg-gradient-to-br from-violet-200 to-purple-200',
      borderColor: 'border-violet-400 hover:border-violet-500',
      defaultCredentials: { email: 'fisioterapeuta@synthonia.bio', password: 'fisioterapeuta123' }
    }
  ];

  const handleProfileSelect = (profile: UserProfile) => {
    const profileData = profiles.find(p => p.type === profile);
    setSelectedProfile(profile);
    if (profileData) {
      setCredentials(prev => ({
        ...prev,
        email: profileData.defaultCredentials.email,
        password: profileData.defaultCredentials.password
      }));
    }
    setError('');
    setMode('login');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProfile) return;

    setIsLoading(true);
    setError('');

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      onLogin(selectedProfile, credentials);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao fazer login. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProfile) return;

    if (credentials.password !== credentials.confirmPassword) {
      setError('As senhas não coincidem');
      return;
    }

    if (credentials.password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log('Registrando usuário:', {
        profile: selectedProfile,
        email: credentials.email,
        name: credentials.name
      });
      
      onRegister(selectedProfile, {
        email: credentials.email,
        password: credentials.password,
        name: credentials.name
      });
      
      console.log('Usuário registrado com sucesso');
      
      // Aguardar um pouco para garantir que o registro foi processado
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setSuccess('Conta criada com sucesso! Você pode fazer login agora.');
      
      // Manter email e limpar apenas senha e confirmação
      setCredentials(prev => ({ 
        ...prev, 
        password: '', 
        confirmPassword: '', 
        name: '' 
      }));
      
      // Aguardar mais um pouco antes de mudar para tela de login
      setTimeout(() => {
        setMode('login');
        setSuccess('');
      }, 2000);
      
    } catch (err) {
      console.error('Erro no registro:', err);
      setError(err instanceof Error ? err.message : 'Erro ao criar conta. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!credentials.email) {
      setError('Digite seu email');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Simular envio de email
      await new Promise(resolve => setTimeout(resolve, 2000));
      setSuccess('Instruções de recuperação enviadas para seu email!');
      setTimeout(() => {
        setMode('login');
        setSuccess('');
      }, 3000);
    } catch (err) {
      setError('Erro ao enviar email. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setCredentials({ email: '', password: '', confirmPassword: '', name: '' });
    setError('');
    setSuccess('');
    setSelectedProfile(null);
    setMode('profile-select');
  };

  const currentProfile = profiles.find(p => p.type === selectedProfile);

  // Profile Selection Screen
  if (mode === 'profile-select') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <div className="max-w-4xl w-full">
          <div className="text-center mb-8 flex flex-col md:flex-row items-center justify-center">
            <img 
              src="/logo copy.png" 
              alt="Synthonia Logo" 
              className="h-20 w-20 md:h-24 md:w-24 mr-0 md:mr-4 mb-4 md:mb-0 object-contain"
              style={{ aspectRatio: '1/1' }}
            />
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                SynthonIA Analytics
              </h1>
              <p className="text-gray-600 text-sm md:text-base">
                Sistema de Análise Neurofisiológica
              </p>
            </div>
          </div>

          <h2 className="text-xl md:text-2xl font-semibold text-center text-gray-800 mb-6">
            Selecione seu Perfil
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
            {profiles.map((profile) => {
              const Icon = profile.icon;
              return (
                <button
                  key={profile.type}
                  onClick={() => handleProfileSelect(profile.type)}
                  className={`${profile.bgColor} rounded-xl shadow-lg p-4 md:p-6 hover:shadow-xl transition-all duration-300 text-left group border-2 ${profile.borderColor}`}
                >
                  <div className={`w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-r ${profile.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-md`}>
                    <Icon className="h-6 w-6 md:h-7 md:w-7 text-white" />
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-2">
                    {profile.title}
                  </h3>
                  <p className="text-gray-700 mb-4 text-sm md:text-base font-medium">
                    {profile.description}
                  </p>
                  <div className="text-xs text-gray-600 bg-white/70 rounded-lg p-3 border border-gray-200">
                    <p><strong>Email:</strong> {profile.defaultCredentials.email}</p>
                    <p><strong>Senha:</strong> {profile.defaultCredentials.password}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Login Screen
  if (mode === 'login') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-6 md:p-8 max-w-md mx-auto w-full">
          <div className="text-center mb-6">
            <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${currentProfile?.color} flex items-center justify-center mx-auto mb-4 shadow-lg`}>
              {React.createElement(currentProfile?.icon!, { className: "h-8 w-8 text-white" })}
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-gray-900">
              Login - {currentProfile?.title}
            </h2>
            <p className="text-gray-600 text-sm mt-2">
              Entre com suas credenciais
            </p>
          </div>

          {success && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-600">{success}</p>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                required
                value={credentials.email}
                onChange={(e) => setCredentials(prev => ({ ...prev, email: e.target.value }))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="seu@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Senha
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={credentials.password}
                  onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-10"
                  placeholder="Sua senha"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <div className="w-5 h-5 rounded-full flex items-center justify-center">
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </div>
                </button>
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            <div className="flex space-x-3 pt-4">
              <button
                type="button"
                onClick={resetForm}
                className="flex-1 py-3 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                disabled={isLoading}
              >
                Voltar
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-3 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Entrando...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 rounded-full flex items-center justify-center">
                      <Lock className="h-3 w-3" />
                    </div>
                    <span>Entrar</span>
                  </div>
                )}
              </button>
            </div>
          </form>

          <div className="mt-6 space-y-3">
            <div className="text-center">
              <button
                onClick={() => setMode('forgot-password')}
                className="text-sm text-blue-600 hover:text-blue-800 transition-colors"
              >
                Esqueceu sua senha?
              </button>
            </div>
            
            <div className="text-center">
              <span className="text-sm text-gray-600">Não tem uma conta? </span>
              <button
                onClick={() => setMode('register')}
                className="text-sm text-blue-600 hover:text-blue-800 font-medium transition-colors"
              >
                Cadastre-se
              </button>
            </div>
          </div>

          <div className="mt-6 p-3 bg-blue-50 rounded-lg">
            <p className="text-xs text-blue-700 text-center">
              <strong>Credenciais de Teste:</strong><br />
              Email: {currentProfile?.defaultCredentials.email}<br />
              Senha: {currentProfile?.defaultCredentials.password}
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Register Screen
  if (mode === 'register') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-6 md:p-8 max-w-md mx-auto w-full">
          <div className="text-center mb-6">
            <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${currentProfile?.color} flex items-center justify-center mx-auto mb-4 shadow-lg`}>
              <UserPlus className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-gray-900">
              Cadastro - {currentProfile?.title}
            </h2>
            <p className="text-gray-600 text-sm mt-2">
              Crie sua conta no SynthonIA
            </p>
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nome Completo
              </label>
              <input
                type="text"
                required
                value={credentials.name}
                onChange={(e) => setCredentials(prev => ({ ...prev, name: e.target.value }))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Seu nome completo"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                required
                value={credentials.email}
                onChange={(e) => setCredentials(prev => ({ ...prev, email: e.target.value }))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="seu@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Senha
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={credentials.password}
                  onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-10"
                  placeholder="Mínimo 6 caracteres"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <div className="w-5 h-5 rounded-full flex items-center justify-center">
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </div>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Confirmar Senha
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  required
                  value={credentials.confirmPassword}
                  onChange={(e) => setCredentials(prev => ({ ...prev, confirmPassword: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-10"
                  placeholder="Confirme sua senha"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <div className="w-5 h-5 rounded-full flex items-center justify-center">
                    {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </div>
                </button>
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            <div className="flex space-x-3 pt-4">
              <button
                type="button"
                onClick={() => setMode('login')}
                className="flex-1 py-3 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                disabled={isLoading}
              >
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-4 h-4 rounded-full flex items-center justify-center">
                    <ArrowLeft className="h-3 w-3" />
                  </div>
                  <span>Voltar</span>
                </div>
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-3 px-4 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Criando...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 rounded-full flex items-center justify-center">
                      <UserPlus className="h-3 w-3" />
                    </div>
                    <span>Criar Conta</span>
                  </div>
                )}
              </button>
            </div>
          </form>

          <div className="mt-6 text-center">
            <span className="text-sm text-gray-600">Já tem uma conta? </span>
            <button
              onClick={() => setMode('login')}
              className="text-sm text-blue-600 hover:text-blue-800 font-medium transition-colors"
            >
              Faça login
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Forgot Password Screen
  if (mode === 'forgot-password') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-6 md:p-8 max-w-md mx-auto w-full">
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Mail className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-gray-900">
              Recuperar Senha
            </h2>
            <p className="text-gray-600 text-sm mt-2">
              Digite seu email para receber instruções
            </p>
          </div>

          {success && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-600">{success}</p>
            </div>
          )}

          <form onSubmit={handleForgotPassword} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                required
                value={credentials.email}
                onChange={(e) => setCredentials(prev => ({ ...prev, email: e.target.value }))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="seu@email.com"
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            <div className="flex space-x-3 pt-4">
              <button
                type="button"
                onClick={() => setMode('login')}
                className="flex-1 py-3 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                disabled={isLoading}
              >
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-4 h-4 rounded-full flex items-center justify-center">
                    <ArrowLeft className="h-3 w-3" />
                  </div>
                  <span>Voltar</span>
                </div>
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-3 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Enviando...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 rounded-full flex items-center justify-center">
                      <Mail className="h-3 w-3" />
                    </div>
                    <span>Enviar</span>
                  </div>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return null;
};

export default LoginForm;
// AI_GENERATED_CODE_END