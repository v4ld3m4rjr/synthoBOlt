import React, { useState } from 'react';
import { User, Trophy, Users, ArrowRight } from 'lucide-react';
import { UserProfile } from '../hooks/useProfile';

interface ProfileSelectorProps {
  onProfileSelect: (profile: UserProfile, data: any) => void;
}

const ProfileSelector: React.FC<ProfileSelectorProps> = ({ onProfileSelect }) => {
  const [selectedProfile, setSelectedProfile] = useState<UserProfile | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    coachEmail: ''
  });

  const profiles = [
    {
      type: 'normal' as UserProfile,
      title: 'Praticante',
      description: 'Acesso completo para monitoramento pessoal de saúde e performance',
      icon: User,
      color: 'from-emerald-500 to-teal-600',
      bgColor: 'bg-gradient-to-br from-emerald-100 to-teal-100',
      borderColor: 'border-emerald-300 hover:border-emerald-400',
      features: ['Análise pessoal completa', 'Relatórios detalhados', 'IA personalizada']
    },
    {
      type: 'athlete' as UserProfile,
      title: 'Atleta',
      description: 'Todas as funcionalidades + conexão com treinador',
      icon: Trophy,
      color: 'from-amber-500 to-orange-600',
      bgColor: 'bg-gradient-to-br from-amber-100 to-orange-100',
      borderColor: 'border-amber-300 hover:border-amber-400',
      features: ['Tudo do praticante', 'Conexão com treinador', 'Análise de performance']
    },
    {
      type: 'coach' as UserProfile,
      title: 'Treinador',
      description: 'Gestão e análise de atletas e equipes',
      icon: Users,
      color: 'from-violet-500 to-purple-600',
      bgColor: 'bg-gradient-to-br from-violet-100 to-purple-100',
      borderColor: 'border-violet-300 hover:border-violet-400',
      features: ['Gestão de atletas', 'Análise de equipe', 'Relatórios comparativos']
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedProfile) {
      onProfileSelect(selectedProfile, formData);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-8 flex items-center justify-center">
          <img 
            src="/logo copy.png" 
            alt="Synthonia Logo" 
            className="h-24 w-24 mr-4 object-contain"
            style={{ aspectRatio: '1/1' }}
          />
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Bem-vindo ao SynthonIA Analytics
            </h1>
            <p className="text-gray-600">
              Escolha seu perfil para personalizar sua experiência
            </p>
          </div>
        </div>

        {!selectedProfile ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {profiles.map((profile) => {
              const Icon = profile.icon;
              return (
                <button
                  key={profile.type}
                  onClick={() => setSelectedProfile(profile.type)}
                  className={`${profile.bgColor} rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 text-left group border-2 ${profile.borderColor}`}
                >
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${profile.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {profile.title}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {profile.description}
                  </p>
                  <ul className="space-y-1">
                    {profile.features.map((feature, index) => (
                      <li key={index} className="text-sm text-gray-500 flex items-center">
                        <div className="w-1.5 h-1.5 rounded-full bg-gray-400 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4 flex items-center text-blue-600 font-medium">
                    Selecionar
                    <ArrowRight className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-lg p-8 max-w-md mx-auto">
            <div className="text-center mb-6">
              <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${profiles.find(p => p.type === selectedProfile)?.color} flex items-center justify-center mx-auto mb-4`}>
                {React.createElement(profiles.find(p => p.type === selectedProfile)?.icon!, { className: "h-8 w-8 text-white" })}
              </div>
              <h2 className="text-2xl font-bold text-gray-900">
                {profiles.find(p => p.type === selectedProfile)?.title}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nome Completo
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Seu nome completo"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="seu@email.com"
                />
              </div>

              {selectedProfile === 'athlete' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email do Treinador
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.coachEmail}
                    onChange={(e) => setFormData(prev => ({ ...prev, coachEmail: e.target.value }))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="treinador@email.com"
                  />
                </div>
              )}

              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setSelectedProfile(null)}
                  className="flex-1 py-3 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Voltar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Continuar
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfileSelector;