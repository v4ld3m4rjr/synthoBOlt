import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Activity, Brain, TrendingUp, BarChart3, Zap, Target, Heart, Gauge } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, AreaChart, Area, Tooltip } from 'recharts';
import { generateEmptyData, getEmptyMetrics, getEmptyRadarData, hasUserData, getEmptyStatus, EmptyTooltip, loadUserRecoveryData } from '../../utils/emptyDataUtils';
import { chartColors, CustomTooltip } from '../../utils/dataUtils';

interface MainDashboardProps {
  userEmail: string | null;
}

const MainDashboard: React.FC<MainDashboardProps> = ({ userEmail }) => {
  const navigate = useNavigate();
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(['recovery']);

  // Carregar dados reais do usuário
  const userRecoveryData = loadUserRecoveryData(userEmail || '');
  const userData = userRecoveryData !== null;
  const metrics = userData ? userRecoveryData : getEmptyMetrics();

  // Dados para gráficos baseados nos dados reais
  const recoveryData = userData ? generateEmptyData(7).map((point, index) => ({
    ...point,
    value: index === 6 ? metrics.recovery : Math.max(0, metrics.recovery + (Math.random() - 0.5) * 2)
  })) : generateEmptyData(7);
  
  const trainingData = userData ? generateEmptyData(7).map((point, index) => ({
    ...point,
    value: index === 6 ? metrics.energy : Math.max(0, metrics.energy + (Math.random() - 0.5) * 2)
  })) : generateEmptyData(7);
  
  const mainMetrics = [
    { key: 'recovery', label: 'Recuperação', value: metrics.recovery, icon: Heart, color: chartColors.success },
    { key: 'energy', label: 'Energia', value: metrics.energy, icon: Zap, color: chartColors.primary },
    { key: 'stress', label: 'Estresse', value: metrics.stress, icon: Brain, color: chartColors.danger },
    { key: 'mood', label: 'Humor', value: metrics.mood, icon: Target, color: chartColors.warning },
    { key: 'sleep', label: 'Sono', value: metrics.sleep, icon: Activity, color: chartColors.purple },
    { key: 'motivation', label: 'Motivação', value: metrics.motivation, icon: TrendingUp, color: chartColors.accent },
  ];

  const radarData = userData ? [
    { subject: 'Recuperação', A: metrics.recovery, fullMark: 10 },
    { subject: 'Energia', A: metrics.energy, fullMark: 10 },
    { subject: 'Sono', A: metrics.sleep, fullMark: 10 },
    { subject: 'Humor', A: metrics.mood, fullMark: 10 },
    { subject: 'Bem-estar', A: metrics.wellbeing, fullMark: 10 },
    { subject: 'Foco', A: metrics.focus, fullMark: 10 },
  ] : getEmptyRadarData();

  // Dados para gráfico com múltiplas métricas
  const multiMetricData = generateEmptyData(7).map(point => {
    const data: any = { date: point.date };
    selectedMetrics.forEach(metric => {
      const metricData = mainMetrics.find(m => m.key === metric);
      if (metricData) {
        data[metric] = metricData.value;
      }
    });
    return data;
  });

  const currentRecovery = { normalized: metrics.recovery };
  const currentTraining = { normalized: metrics.energy };

  const toggleMetric = (metricKey: string) => {
    setSelectedMetrics(prev => 
      prev.includes(metricKey) 
        ? prev.filter(m => m !== metricKey)
        : [...prev, metricKey]
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-2 md:p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-4 md:mb-8">
          <div className="text-center md:text-left">
            <h1 className="text-xl md:text-3xl font-bold text-gray-900 mb-2">
              Dashboard Principal
            </h1>
            <p className="text-sm md:text-base text-gray-600">
              {userData ? 'Acompanhe seus dados de performance e bem-estar' : 'Comece registrando seus dados para ver análises personalizadas'}
            </p>
          </div>
        </div>

        {/* Alerta para usuários sem dados */}
        {!userData && (
          <div className="mb-4 md:mb-6 bg-blue-50 border border-blue-200 rounded-lg p-3 md:p-4">
            <div className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-blue-600" />
              <div>
                <h3 className="text-sm md:text-base font-medium text-blue-800">Bem-vindo ao SynthonIA!</h3>
                <p className="text-xs md:text-sm text-blue-700 mt-1">
                  Você ainda não possui dados registrados. Comece preenchendo suas informações de recuperação e treino para ver análises personalizadas.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Grid de Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 md:gap-6">
          
          {/* Card 1 - Dashboard Principal (Grande) - Verde Claro */}
          <div className="lg:col-span-8 bg-gradient-to-br from-green-100 to-emerald-100 rounded-xl shadow-lg p-4 md:p-6 hover:shadow-xl transition-all duration-300 border-2 border-green-300 hover:border-green-400">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 md:mb-6">
              <h2 className="text-lg md:text-xl font-semibold text-gray-800 flex items-center mb-3 md:mb-0">
                <BarChart3 className="mr-2 h-5 w-5 text-green-700" />
                Métricas Principais
              </h2>
              <div className="flex flex-wrap gap-1 md:gap-2">
                {mainMetrics.map((metric) => (
                  <button
                    key={metric.key}
                    onClick={() => toggleMetric(metric.key)}
                    className={`px-2 md:px-3 py-1 rounded-full text-xs md:text-sm font-medium transition-all duration-200 ${
                      selectedMetrics.includes(metric.key)
                        ? 'text-white shadow-md'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                    style={{
                      backgroundColor: selectedMetrics.includes(metric.key) ? metric.color : undefined
                    }}
                  >
                    {metric.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
              {/* Gráfico das Métricas Selecionadas */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm md:text-lg font-medium text-gray-700">
                    Evolução - Últimos 7 dias
                  </h3>
                  <div className="hidden md:flex items-center space-x-2">
                    {selectedMetrics.map(metricKey => {
                      const metric = mainMetrics.find(m => m.key === metricKey);
                      return metric ? (
                        <div key={metricKey} className="flex items-center space-x-1">
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: metric.color }}
                          />
                          <span className="text-xs text-gray-600">{metric.label}</span>
                        </div>
                      ) : null;
                    })}
                  </div>
                </div>
                
                <div className="h-32 md:h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={multiMetricData}>
                      <XAxis dataKey="date" />
                      <YAxis domain={[0, 10]} />
                      <Tooltip content={userData ? <CustomTooltip /> : <EmptyTooltip />} />
                      {selectedMetrics.map(metricKey => {
                        const metric = mainMetrics.find(m => m.key === metricKey);
                        return metric ? (
                          <Line
                            key={metricKey}
                            type="monotone"
                            dataKey={metricKey}
                            stroke={metric.color}
                            strokeWidth={2}
                            dot={{ fill: metric.color, r: 4 }}
                            name={metric.label}
                          />
                        ) : null;
                      })}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Radar Chart - Visão Geral */}
              <div className="space-y-4">
                <h3 className="text-sm md:text-lg font-medium text-gray-700">Estado Atual</h3>
                <div className="h-32 md:h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="subject" tick={{ fontSize: 8 }} />
                      <PolarRadiusAxis angle={90} domain={[0, 10]} tick={{ fontSize: 6 }} />
                      <Tooltip content={userData ? <CustomTooltip /> : <EmptyTooltip />} />
                      <Radar
                        name="Atual"
                        dataKey="A"
                        stroke="#059669"
                        fill="#059669"
                        fillOpacity={0.3}
                        strokeWidth={2}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Grid de Métricas */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-4 mt-4 md:mt-6">
              {mainMetrics.map((metric) => {
                const Icon = metric.icon;
                const isSelected = selectedMetrics.includes(metric.key);
                return (
                  <div
                    key={metric.key}
                    className={`p-2 md:p-4 rounded-lg border-2 transition-all duration-200 cursor-pointer ${
                      isSelected
                        ? 'border-green-400 bg-green-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => toggleMetric(metric.key)}
                  >
                    <div className="flex items-center space-x-2 md:space-x-3">
                      <div className="w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: `${metric.color}20` }}>
                        <Icon className="h-3 w-3 md:h-4 md:w-4" style={{ color: metric.color }} />
                      </div>
                      <div>
                        <p className="text-xs md:text-sm font-medium text-gray-600">{metric.label}</p>
                        <p className="text-sm md:text-lg font-bold" style={{ color: metric.color }}>
                          {metric.value}/10
                        </p>
                        {!userData && (
                          <p className="text-xs text-gray-500">{getEmptyStatus(metric.key)}</p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Card 2 - Recuperação - Azul Claro */}
          <div className="lg:col-span-4 bg-gradient-to-br from-blue-100 to-sky-100 rounded-xl shadow-lg p-4 md:p-6 hover:shadow-xl transition-all duration-300 cursor-pointer border-2 border-blue-300 hover:border-blue-400"
               onClick={() => navigate('/recovery')}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base md:text-lg font-semibold text-gray-800 flex items-center">
                <div className="w-6 h-6 rounded-full bg-blue-200 flex items-center justify-center mr-2">
                  <Heart className="h-4 w-4 text-blue-700" />
                </div>
                Recuperação
              </h2>
              <div className="text-right">
                <p className="text-lg md:text-2xl font-bold text-blue-700">
                  {currentRecovery.normalized.toFixed(1)}/10
                </p>
                <p className="text-xs md:text-sm text-gray-500">
                  {userData ? 'Muito Boa' : 'Sem dados'}
                </p>
              </div>
            </div>

            <div className="h-16 md:h-24 mb-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={recoveryData}>
                  <XAxis dataKey="date" />
                  <YAxis domain={[0, 10]} hide />
                  <Tooltip content={userData ? <CustomTooltip /> : <EmptyTooltip />} />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#1d4ed8"
                    strokeWidth={2}
                    dot={{ fill: '#1d4ed8', r: 3 }}
                    name="Recuperação"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-2 md:gap-4 text-xs md:text-sm">
              <div>
                <p className="text-gray-500">Energia</p>
                <p className="font-semibold text-blue-600">0/10</p>
              </div>
              <div>
                <p className="text-gray-500">Sono</p>
                <p className="font-semibold text-purple-600">0/10</p>
              </div>
            </div>
          </div>

          {/* Card 3 - Carga de Treino - Laranja Claro */}
          <div className="lg:col-span-4 bg-gradient-to-br from-orange-100 to-amber-100 rounded-xl shadow-lg p-4 md:p-6 hover:shadow-xl transition-all duration-300 cursor-pointer border-2 border-orange-300 hover:border-orange-400"
               onClick={() => navigate('/training')}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base md:text-lg font-semibold text-gray-800 flex items-center">
                <div className="w-6 h-6 rounded-full bg-orange-200 flex items-center justify-center mr-2">
                  <Activity className="h-4 w-4 text-orange-700" />
                </div>
                Carga de Treino
              </h2>
              <div className="text-right">
                <p className="text-lg md:text-2xl font-bold text-orange-700">
                  {currentTraining.normalized.toFixed(1)}/10
                </p>
                <p className="text-xs md:text-sm text-gray-500">
                  {userData ? 'Moderada' : 'Sem dados'}
                </p>
              </div>
            </div>

            <div className="h-16 md:h-24 mb-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trainingData}>
                  <XAxis dataKey="date" />
                  <YAxis domain={[0, 10]} hide />
                  <Tooltip content={userData ? <CustomTooltip /> : <EmptyTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#c2410c"
                    fill="#c2410c"
                    fillOpacity={0.3}
                    strokeWidth={2}
                    name="Carga de Treino"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-2 md:gap-4 text-xs md:text-sm">
              <div>
                <p className="text-gray-500">TRIMP</p>
                <p className="font-semibold text-orange-700">0</p>
              </div>
              <div>
                <p className="text-gray-500">RPE</p>
                <p className="font-semibold text-red-600">0/10</p>
              </div>
            </div>
          </div>

          {/* Card 4 - Análise IA - Roxo */}
          <div className="lg:col-span-4 bg-gradient-to-br from-purple-100 to-violet-100 rounded-xl shadow-lg p-4 md:p-6 hover:shadow-xl transition-all duration-300 cursor-pointer border-2 border-purple-300 hover:border-purple-400"
               onClick={() => navigate('/ai-analysis')}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base md:text-lg font-semibold text-gray-800 flex items-center">
                <div className="w-6 h-6 rounded-full bg-purple-200 flex items-center justify-center mr-2">
                  <Brain className="h-4 w-4 text-purple-700" />
                </div>
                Análise IA
              </h2>
              <div className={`w-3 h-3 rounded-full ${userData ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
            </div>

            <div className="space-y-3">
              <div className="bg-white/70 rounded-lg p-2 md:p-3">
                <p className="text-xs md:text-sm font-medium text-gray-800 mb-1">
                  {userData ? 'Prioridade Atual' : 'Aguardando Dados'}
                </p>
                <p className="text-xs md:text-sm text-gray-600">
                  {userData ? 'Melhore a qualidade do sono para otimizar a recuperação' : 'Registre seus dados para receber análises personalizadas'}
                </p>
              </div>

              <div className="bg-white/70 rounded-lg p-2 md:p-3">
                <p className="text-xs md:text-sm font-medium text-gray-800 mb-1">
                  {userData ? 'Alerta' : 'Recomendação'}
                </p>
                <p className="text-xs md:text-sm text-gray-600">
                  {userData ? 'Níveis de estresse elevados nos últimos 3 dias' : 'Comece preenchendo dados de recuperação'}
                </p>
              </div>

              <div className="bg-white/70 rounded-lg p-2 md:p-3">
                <p className="text-xs md:text-sm font-medium text-gray-800 mb-1">
                  {userData ? 'Tendência' : 'Próximo Passo'}
                </p>
                <p className="text-xs md:text-sm text-gray-600">
                  {userData ? 'Recuperação melhorando gradualmente' : 'Registre dados de treino para análises completas'}
                </p>
              </div>
            </div>
          </div>

          {/* Card 5 - Reabilitação & Dor - Vermelho */}
          <div className="lg:col-span-4 bg-gradient-to-br from-red-100 to-pink-100 rounded-xl shadow-lg p-4 md:p-6 hover:shadow-xl transition-all duration-300 cursor-pointer border-2 border-red-300 hover:border-red-400"
               onClick={() => navigate('/rehabilitation')}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base md:text-lg font-semibold text-gray-800 flex items-center">
                <div className="w-6 h-6 rounded-full bg-red-200 flex items-center justify-center mr-2">
                  <Brain className="h-4 w-4 text-red-700" />
                </div>
                Reabilitação & Dor
              </h2>
              <div className="w-5 h-5 rounded-full bg-red-200 flex items-center justify-center">
                <Target className="h-3 w-3 text-red-700" />
              </div>
            </div>

            <div className="space-y-3">
              <div className="bg-white/70 rounded-lg p-2 md:p-3">
                <p className="text-xs md:text-sm font-medium text-gray-800 mb-1">
                  {userData ? 'Mapa Corporal' : 'Aguardando Dados'}
                </p>
                <p className="text-xs md:text-sm text-gray-600">
                  {userData ? 'Monitore dores e correlações' : 'Registre suas dores para análise'}
                </p>
              </div>

              <div className="bg-white/70 rounded-lg p-2 md:p-3">
                <p className="text-xs md:text-sm font-medium text-gray-800 mb-1">
                  {userData ? 'Correlações' : 'Fatores'}
                </p>
                <p className="text-xs md:text-sm text-gray-600">
                  {userData ? 'Estresse, sono e outros fatores' : 'Analise fatores que influenciam a dor'}
                </p>
              </div>

              <div className="bg-white/70 rounded-lg p-2 md:p-3">
                <p className="text-xs md:text-sm font-medium text-gray-800 mb-1">
                  {userData ? 'Recomendações' : 'Próximo Passo'}
                </p>
                <p className="text-xs md:text-sm text-gray-600">
                  {userData ? 'Sugestões personalizadas' : 'Comece mapeando suas dores'}
                </p>
              </div>
            </div>
          </div>

          {/* Card 6 - Dashboard de Análise - Azul Diferente */}
          <div className="lg:col-span-4 bg-gradient-to-br from-indigo-100 to-blue-100 rounded-xl shadow-lg p-4 md:p-6 hover:shadow-xl transition-all duration-300 cursor-pointer border-2 border-indigo-300 hover:border-indigo-400"
               onClick={() => navigate('/analytics')}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base md:text-lg font-semibold text-gray-800 flex items-center">
                <div className="w-6 h-6 rounded-full bg-indigo-200 flex items-center justify-center mr-2">
                  <Gauge className="h-4 w-4 text-indigo-700" />
                </div>
                Analytics
              </h2>
              <div className="w-5 h-5 rounded-full bg-indigo-200 flex items-center justify-center">
                <TrendingUp className="h-3 w-3 text-indigo-700" />
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2 md:gap-4">
                <div className="bg-white/70 rounded-lg p-2 md:p-3 text-center">
                  <p className="text-sm md:text-lg font-bold text-green-600">{userData ? '24' : '0'}</p>
                  <p className="text-xs text-gray-600">Variáveis</p>
                </div>
                <div className="bg-white/70 rounded-lg p-2 md:p-3 text-center">
                  <p className="text-sm md:text-lg font-bold text-indigo-700">{userData ? '7d' : '0d'}</p>
                  <p className="text-xs text-gray-600">Período</p>
                </div>
              </div>

              <div className="bg-white/70 rounded-lg p-2 md:p-3">
                <p className="text-xs md:text-sm font-medium text-gray-800 mb-2">
                  {userData ? 'Correlações Detectadas' : 'Aguardando Dados'}
                </p>
                <div className="space-y-1">
                  {userData ? (
                    <>
                      <div className="flex justify-between text-xs">
                        <span>Sono ↔ Recuperação</span>
                        <span className="font-semibold text-green-600">+0.85</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Estresse ↔ Humor</span>
                        <span className="font-semibold text-red-600">-0.72</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Treino ↔ Energia</span>
                        <span className="font-semibold text-indigo-700">+0.61</span>
                      </div>
                    </>
                  ) : (
                    <p className="text-xs text-gray-500">
                      Registre dados por alguns dias para ver correlações
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainDashboard;