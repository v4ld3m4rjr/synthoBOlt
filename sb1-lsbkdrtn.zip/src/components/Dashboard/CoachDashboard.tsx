import React, { useState } from 'react';
import { Users, User, BarChart3, TrendingUp, Activity, Heart, Brain, Trophy, Eye } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip, AreaChart, Area } from 'recharts';
import { generateEmptyData, hasUserData, EmptyTooltip } from '../../utils/emptyDataUtils';
import { CustomTooltip, chartColors } from '../../utils/dataUtils';

interface Athlete {
  id: string;
  name: string;
  email: string;
  sport: string;
  position?: string;
  joinDate: string;
  status: 'active' | 'inactive' | 'injured';
  lastUpdate: string;
  metrics: {
    recovery: number;
    energy: number;
    stress: number;
    training: number;
  };
}

interface CoachDashboardProps {
  userEmail: string | null;
}

const CoachDashboard: React.FC<CoachDashboardProps> = ({ userEmail }) => {
  const [selectedView, setSelectedView] = useState<'overview' | 'individual' | 'team'>('overview');
  const [selectedAthletes, setSelectedAthletes] = useState<string[]>([]);
  const [selectedAthlete, setSelectedAthlete] = useState<string | null>(null);

  // Verificar se o treinador tem dados/atletas
  const hasData = hasUserData(userEmail || '');

  // Dados mockados de atletas
  const athletes: Athlete[] = hasData ? [] : []; // Lista vazia se não há dados

  const toggleAthleteSelection = (athleteId: string) => {
    setSelectedAthletes(prev => 
      prev.includes(athleteId) 
        ? prev.filter(id => id !== athleteId)
        : [...prev, athleteId]
    );
  };

  const selectAllAthletes = () => {
    setSelectedAthletes(athletes.map(a => a.id));
  };

  const clearSelection = () => {
    setSelectedAthletes([]);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-100';
      case 'injured': return 'text-red-600 bg-red-100';
      case 'inactive': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Ativo';
      case 'injured': return 'Lesionado';
      case 'inactive': return 'Inativo';
      default: return 'Desconhecido';
    }
  };

  // Função para selecionar atleta para análise individual
  const selectAthleteForAnalysis = (athleteId: string) => {
    setSelectedAthlete(athleteId);
    setSelectedView('individual');
  };

  // Dados para análise da equipe
  const teamData = hasData ? [] : generateEmptyData(7);
  const teamMetrics = {
    totalAthletes: athletes.length,
    activeAthletes: athletes.filter(a => a.status === 'active').length,
    injuredAthletes: athletes.filter(a => a.status === 'injured').length,
    avgRecovery: athletes.length > 0 ? athletes.reduce((sum, a) => sum + a.metrics.recovery, 0) / athletes.length : 0,
    avgEnergy: athletes.length > 0 ? athletes.reduce((sum, a) => sum + a.metrics.energy, 0) / athletes.length : 0,
    avgStress: athletes.length > 0 ? athletes.reduce((sum, a) => sum + a.metrics.stress, 0) / athletes.length : 0,
  };

  const selectedAthleteData = selectedAthlete ? athletes.find(a => a.id === selectedAthlete) : null;

  // Dados individuais do atleta selecionado
  const individualData = selectedAthleteData ? generateEmptyData(7).map(point => ({
    ...point,
    recovery: 0,
    energy: 0,
    stress: 0,
    training: 0,
  })) : [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 to-purple-50 p-2 md:p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-4 md:mb-8">
          <div className="text-center md:text-left">
            <h1 className="text-xl md:text-3xl font-bold text-gray-900 mb-2">
              Dashboard do Treinador
            </h1>
            <p className="text-sm md:text-base text-gray-600">
              {hasData ? 'Gerencie e analise a performance dos seus atletas' : 'Comece adicionando atletas para gerenciar suas performances'}
            </p>
          </div>
        </div>

        {/* Alerta para treinadores sem dados */}
        {!hasData && (
          <div className="mb-4 md:mb-6 bg-violet-50 border border-violet-200 rounded-lg p-3 md:p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-violet-600" />
              <div>
                <h3 className="text-sm md:text-base font-medium text-violet-800">Bem-vindo, Treinador!</h3>
                <p className="text-xs md:text-sm text-violet-700 mt-1">
                  Você ainda não possui atletas cadastrados. Comece adicionando atletas para acompanhar suas performances e gerar análises comparativas.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="mb-6">
          <div className="flex bg-white rounded-lg p-1 shadow-md max-w-fit mx-auto md:mx-0">
            <button
              onClick={() => setSelectedView('overview')}
              className={`px-3 md:px-4 py-2 rounded-md text-xs md:text-sm font-medium transition-colors ${
                selectedView === 'overview' 
                  ? 'bg-violet-600 text-white' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Visão Geral
            </button>
            <button
              onClick={() => setSelectedView('individual')}
              className={`px-3 md:px-4 py-2 rounded-md text-xs md:text-sm font-medium transition-colors ${
                selectedView === 'individual' 
                  ? 'bg-violet-600 text-white' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Individual
            </button>
            <button
              onClick={() => setSelectedView('team')}
              className={`px-3 md:px-4 py-2 rounded-md text-xs md:text-sm font-medium transition-colors ${
                selectedView === 'team' 
                  ? 'bg-violet-600 text-white' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Equipe
            </button>
          </div>
        </div>

        {selectedView === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 md:gap-6">
            {/* Lista de Atletas ou Mensagem Vazia */}
            <div className="lg:col-span-8 bg-white rounded-xl shadow-lg p-4 md:p-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 md:mb-6">
                <h2 className="text-lg md:text-xl font-semibold text-gray-800 flex items-center mb-3 md:mb-0">
                  <Users className="mr-2 h-5 w-5 text-violet-600" />
                  Meus Atletas ({athletes.length})
                </h2>
                {athletes.length > 0 && (
                  <div className="flex space-x-2">
                    <button
                      onClick={selectAllAthletes}
                      className="px-3 py-1 bg-violet-100 text-violet-700 rounded-lg text-sm hover:bg-violet-200 transition-colors"
                    >
                      Selecionar Todos
                    </button>
                    <button
                      onClick={clearSelection}
                      className="px-3 py-1 bg-gray-100 text-gray-700 rounded-lg text-sm hover:bg-gray-200 transition-colors"
                    >
                      Limpar
                    </button>
                  </div>
                )}
              </div>

              {athletes.length === 0 ? (
                <div className="text-center py-8 md:py-12">
                  <Users className="h-12 md:h-16 w-12 md:w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg md:text-xl font-semibold text-gray-600 mb-2">
                    Nenhum atleta cadastrado
                  </h3>
                  <p className="text-sm md:text-base text-gray-500 mb-6">
                    Comece adicionando atletas para acompanhar suas performances
                  </p>
                  <button className="px-4 md:px-6 py-2 md:py-3 bg-violet-600 text-white rounded-lg hover:bg-violet-700 transition-colors">
                    Adicionar Primeiro Atleta
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {athletes.map((athlete) => (
                    <div
                      key={athlete.id}
                      className={`p-3 md:p-4 rounded-lg border-2 transition-all duration-200 cursor-pointer ${
                        selectedAthletes.includes(athlete.id)
                          ? 'border-violet-300 bg-violet-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => toggleAthleteSelection(athlete.id)}
                    >
                      {/* Conteúdo do atleta aqui */}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Resumo da Equipe */}
            <div className="lg:col-span-4 space-y-4 md:space-y-6">
              {/* Estatísticas Gerais */}
              <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
                <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4 flex items-center">
                  <BarChart3 className="mr-2 h-5 w-5 text-violet-600" />
                  Estatísticas da Equipe
                </h3>
                <div className="space-y-3 md:space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm md:text-base text-gray-600">Total de Atletas</span>
                    <span className="font-semibold text-violet-600">{teamMetrics.totalAthletes}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm md:text-base text-gray-600">Ativos</span>
                    <span className="font-semibold text-green-600">{teamMetrics.activeAthletes}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm md:text-base text-gray-600">Lesionados</span>
                    <span className="font-semibold text-red-600">{teamMetrics.injuredAthletes}</span>
                  </div>
                  <hr className="my-3" />
                  <div className="flex justify-between items-center">
                    <span className="text-sm md:text-base text-gray-600">Recuperação Média</span>
                    <span className="font-semibold text-green-600">{teamMetrics.avgRecovery.toFixed(1)}/10</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm md:text-base text-gray-600">Energia Média</span>
                    <span className="font-semibold text-blue-600">{teamMetrics.avgEnergy.toFixed(1)}/10</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm md:text-base text-gray-600">Estresse Médio</span>
                    <span className="font-semibold text-red-600">{teamMetrics.avgStress.toFixed(1)}/10</span>
                  </div>
                </div>
              </div>

              {/* Evolução da Equipe */}
              <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
                <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4 flex items-center">
                  <TrendingUp className="mr-2 h-5 w-5 text-green-600" />
                  Evolução da Equipe
                </h3>
                <div className="h-32 md:h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={teamData}>
                      <XAxis dataKey="date" />
                      <YAxis domain={[0, 10]} />
                      <Tooltip content={hasData ? <CustomTooltip /> : <EmptyTooltip />} />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke={chartColors.purple}
                        strokeWidth={2}
                        dot={{ fill: chartColors.purple, r: 3 }}
                        name="Performance Média"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Alertas */}
              <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
                <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4 flex items-center">
                  <Brain className="mr-2 h-5 w-5 text-orange-600" />
                  Alertas
                </h3>
                {hasData ? (
                  <div className="space-y-3">
                    <div className="p-3 bg-red-50 rounded-lg">
                      <p className="text-sm font-medium text-red-800">Pedro Costa</p>
                      <p className="text-xs text-red-600">Estresse elevado - Requer atenção</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-sm text-gray-500">
                      Nenhum alerta no momento
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      Adicione atletas para receber alertas
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Outras views permanecem similares, mas com verificações de hasData */}
        {selectedView === 'individual' && (
          <div className="bg-white rounded-xl shadow-lg p-4 md:p-8">
            <div className="text-center">
              <User className="h-12 md:h-16 w-12 md:w-16 text-gray-400 mx-auto mb-4" />
              <h2 className="text-lg md:text-xl font-semibold text-gray-700 mb-2">
                {hasData ? 'Selecione um Atleta' : 'Nenhum Atleta Disponível'}
              </h2>
              <p className="text-sm md:text-base text-gray-500">
                {hasData ? 'Escolha um atleta para ver análise individual' : 'Adicione atletas para ver análises individuais'}
              </p>
            </div>
          </div>
        )}

        {selectedView === 'team' && (
          <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
            <h2 className="text-lg md:text-2xl font-semibold text-gray-900 mb-4 md:mb-6">
              Análise da Equipe
            </h2>
            {hasData ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                {/* Gráficos da equipe */}
              </div>
            ) : (
              <div className="text-center py-8 md:py-12">
                <Users className="h-12 md:h-16 w-12 md:w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg md:text-xl font-semibold text-gray-600 mb-2">
                  Análise de equipe indisponível
                </h3>
                <p className="text-sm md:text-base text-gray-500">
                  Adicione atletas para gerar análises comparativas da equipe
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default CoachDashboard;