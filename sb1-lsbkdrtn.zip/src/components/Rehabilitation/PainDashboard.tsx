// [AI Generated] Data: 04/01/2025
// Descrição: Dashboard de análise de dor com gráficos e correlações
// Gerado por: Cursor AI
// Versão: React 18.3.1, TypeScript 5.5.3
// AI_GENERATED_CODE_START
import React, { useState } from 'react';
import { TrendingUp, AlertTriangle, Target, Activity, Brain, Heart } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip, ScatterChart, Scatter, BarChart, Bar, AreaChart, Area } from 'recharts';
import { CustomTooltip, chartColors } from '../../utils/dataUtils';

interface PainDashboardProps {
  painData: { [key: string]: number };
  correlationData: {
    stress: number;
    sleep: number;
    mood: number;
    recovery: number;
    training: number;
    weather: number;
    hydration: number;
    nutrition: number;
  };
  painEvolutionData: any[];
  correlationChartData: any[];
  getHighestPainAreas: () => Array<{ area: string; value: number }>;
  getAveragePain: () => number;
  getPainLevel: (value: number) => { text: string; color: string };
}

const PainDashboard: React.FC<PainDashboardProps> = ({
  painData,
  correlationData,
  painEvolutionData,
  correlationChartData,
  getHighestPainAreas,
  getAveragePain,
  getPainLevel
}) => {
  const [selectedCorrelations, setSelectedCorrelations] = useState<string[]>(['stress', 'sleep']);

  const highestPainAreas = getHighestPainAreas();
  const averagePain = getAveragePain();
  const painLevel = getPainLevel(averagePain);

  // Dados para análise de correlação
  const correlationAnalysis = Object.entries(correlationData).map(([factor, value]) => {
    // Simular correlação com dor
    const correlation = Math.random() * 2 - 1; // -1 a 1
    return {
      factor: factor.charAt(0).toUpperCase() + factor.slice(1),
      value,
      correlation: correlation.toFixed(2),
      strength: Math.abs(correlation) > 0.7 ? 'Forte' : Math.abs(correlation) > 0.4 ? 'Moderada' : 'Fraca'
    };
  });

  // Dados para gráfico de dispersão
  const scatterData = correlationAnalysis.map(item => ({
    x: item.value,
    y: averagePain + (Math.random() - 0.5) * 2,
    factor: item.factor
  }));

  // Dados para radar de fatores
  const radarData = [
    { subject: 'Estresse', A: correlationData.stress, fullMark: 10 },
    { subject: 'Sono', A: correlationData.sleep, fullMark: 10 },
    { subject: 'Humor', A: correlationData.mood, fullMark: 10 },
    { subject: 'Recuperação', A: correlationData.recovery, fullMark: 10 },
    { subject: 'Treino', A: correlationData.training, fullMark: 10 },
    { subject: 'Hidratação', A: correlationData.hydration, fullMark: 10 },
  ];

  // Recomendações baseadas nos dados
  const getRecommendations = () => {
    const recommendations = [];
    
    if (averagePain > 6) {
      recommendations.push({
        type: 'warning',
        title: 'Dor Elevada Detectada',
        message: 'Considere reduzir a intensidade dos treinos e focar na recuperação.',
        icon: AlertTriangle
      });
    }
    
    if (correlationData.stress > 7) {
      recommendations.push({
        type: 'info',
        title: 'Estresse Alto',
        message: 'Técnicas de relaxamento podem ajudar a reduzir a dor.',
        icon: Brain
      });
    }
    
    if (correlationData.sleep < 4) {
      recommendations.push({
        type: 'warning',
        title: 'Sono Inadequado',
        message: 'Melhore a qualidade do sono para acelerar a recuperação.',
        icon: Heart
      });
    }
    
    if (correlationData.hydration < 5) {
      recommendations.push({
        type: 'info',
        title: 'Hidratação Baixa',
        message: 'Aumente a ingestão de água para reduzir tensões musculares.',
        icon: Activity
      });
    }
    
    return recommendations;
  };

  const recommendations = getRecommendations();

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 md:gap-4">
        <div className="bg-white rounded-xl shadow-lg p-4 md:p-6 text-center">
          <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-3">
            <Target className="h-6 w-6 text-red-600" />
          </div>
          <h3 className="text-sm font-medium text-gray-600">Dor Média</h3>
          <p className={`text-2xl font-bold ${painLevel.color}`}>
            {averagePain.toFixed(1)}/10
          </p>
          <p className={`text-sm ${painLevel.color}`}>
            {painLevel.text}
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 md:p-6 text-center">
          <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center mx-auto mb-3">
            <AlertTriangle className="h-6 w-6 text-orange-600" />
          </div>
          <h3 className="text-sm font-medium text-gray-600">Áreas Afetadas</h3>
          <p className="text-2xl font-bold text-orange-600">
            {Object.values(painData).filter(v => v > 0).length}
          </p>
          <p className="text-sm text-orange-600">
            Regiões com dor
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 md:p-6 text-center">
          <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-3">
            <TrendingUp className="h-6 w-6 text-blue-600" />
          </div>
          <h3 className="text-sm font-medium text-gray-600">Tendência</h3>
          <p className="text-2xl font-bold text-blue-600">
            {Math.random() > 0.5 ? '↗' : '↘'}
          </p>
          <p className="text-sm text-blue-600">
            {Math.random() > 0.5 ? 'Aumentando' : 'Diminuindo'}
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 md:p-6 text-center">
          <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-3">
            <Activity className="h-6 w-6 text-green-600" />
          </div>
          <h3 className="text-sm font-medium text-gray-600">Correlação Forte</h3>
          <p className="text-2xl font-bold text-green-600">
            {correlationAnalysis.filter(c => c.strength === 'Forte').length}
          </p>
          <p className="text-sm text-green-600">
            Fatores identificados
          </p>
        </div>
      </div>

      {/* Gráficos Principais */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Evolução da Dor */}
        <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <TrendingUp className="mr-2 h-5 w-5 text-red-600" />
            Evolução da Dor - 7 Dias
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={painEvolutionData}>
                <XAxis dataKey="date" />
                <YAxis domain={[0, 10]} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="pain"
                  stroke={chartColors.danger}
                  strokeWidth={3}
                  dot={{ fill: chartColors.danger, r: 4 }}
                  name="Dor"
                />
                <Line
                  type="monotone"
                  dataKey="stress"
                  stroke={chartColors.warning}
                  strokeWidth={2}
                  dot={{ fill: chartColors.warning, r: 3 }}
                  name="Estresse"
                />
                <Line
                  type="monotone"
                  dataKey="sleep"
                  stroke={chartColors.primary}
                  strokeWidth={2}
                  dot={{ fill: chartColors.primary, r: 3 }}
                  name="Sono"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Fatores Correlacionados */}
        <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <Brain className="mr-2 h-5 w-5 text-purple-600" />
            Estado dos Fatores
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10 }} />
                <PolarRadiusAxis angle={90} domain={[0, 10]} tick={{ fontSize: 8 }} />
                <Tooltip content={<CustomTooltip />} />
                <Radar
                  name="Fatores"
                  dataKey="A"
                  stroke={chartColors.purple}
                  fill={chartColors.purple}
                  fillOpacity={0.3}
                  strokeWidth={2}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Áreas com Maior Dor */}
        <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <AlertTriangle className="mr-2 h-5 w-5 text-orange-600" />
            Áreas Mais Afetadas
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={highestPainAreas} layout="horizontal">
                <XAxis type="number" domain={[0, 10]} />
                <YAxis dataKey="area" type="category" width={100} tick={{ fontSize: 10 }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar
                  dataKey="value"
                  fill={chartColors.danger}
                  radius={[0, 4, 4, 0]}
                  name="Nível de Dor"
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Análise de Correlação */}
        <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <Activity className="mr-2 h-5 w-5 text-green-600" />
            Correlações Detectadas
          </h3>
          <div className="space-y-3">
            {correlationAnalysis.slice(0, 6).map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-gray-800">
                    {item.factor === 'Stress' ? 'Estresse' :
                     item.factor === 'Sleep' ? 'Sono' :
                     item.factor === 'Mood' ? 'Humor' :
                     item.factor === 'Recovery' ? 'Recuperação' :
                     item.factor === 'Training' ? 'Treino' :
                     item.factor === 'Weather' ? 'Clima' :
                     item.factor === 'Hydration' ? 'Hidratação' :
                     item.factor === 'Nutrition' ? 'Nutrição' : item.factor}
                  </p>
                  <p className="text-xs text-gray-500">Correlação {item.strength}</p>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-bold ${
                    parseFloat(item.correlation) > 0.5 ? 'text-red-600' :
                    parseFloat(item.correlation) < -0.5 ? 'text-green-600' : 'text-gray-600'
                  }`}>
                    {parseFloat(item.correlation) > 0 ? '+' : ''}{item.correlation}
                  </p>
                  <p className="text-xs text-gray-500">Valor: {item.value}/10</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recomendações */}
      <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <Target className="mr-2 h-5 w-5 text-blue-600" />
          Recomendações Personalizadas
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recommendations.length > 0 ? recommendations.map((rec, index) => {
            const Icon = rec.icon;
            return (
              <div key={index} className={`p-4 rounded-lg border-l-4 ${
                rec.type === 'warning' ? 'bg-yellow-50 border-yellow-500' : 'bg-blue-50 border-blue-500'
              }`}>
                <div className="flex items-start space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    rec.type === 'warning' ? 'bg-yellow-100' : 'bg-blue-100'
                  }`}>
                    <Icon className={`h-4 w-4 ${
                      rec.type === 'warning' ? 'text-yellow-600' : 'text-blue-600'
                    }`} />
                  </div>
                  <div>
                    <h4 className={`font-medium ${
                      rec.type === 'warning' ? 'text-yellow-800' : 'text-blue-800'
                    }`}>
                      {rec.title}
                    </h4>
                    <p className={`text-sm mt-1 ${
                      rec.type === 'warning' ? 'text-yellow-700' : 'text-blue-700'
                    }`}>
                      {rec.message}
                    </p>
                  </div>
                </div>
              </div>
            );
          }) : (
            <div className="col-span-2 text-center py-8">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-green-600" />
              </div>
              <h4 className="text-lg font-medium text-gray-800 mb-2">
                Tudo Parece Bem!
              </h4>
              <p className="text-gray-600">
                Não há recomendações específicas no momento. Continue monitorando seus dados.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Insights Adicionais */}
      <div className="bg-gradient-to-br from-red-50 to-pink-50 rounded-xl p-4 md:p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Insights da Análise
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/70 rounded-lg p-4">
            <h4 className="font-semibold text-gray-800 mb-2">Padrão Identificado</h4>
            <p className="text-sm text-gray-700">
              {averagePain > 5 
                ? 'Dor elevada pode estar relacionada ao estresse e qualidade do sono.'
                : 'Níveis de dor controlados. Continue monitorando os fatores correlacionados.'}
            </p>
          </div>
          <div className="bg-white/70 rounded-lg p-4">
            <h4 className="font-semibold text-gray-800 mb-2">Fator Principal</h4>
            <p className="text-sm text-gray-700">
              {correlationAnalysis.length > 0 
                ? `${correlationAnalysis[0].factor} apresenta maior correlação com a dor.`
                : 'Continue registrando dados para identificar correlações.'}
            </p>
          </div>
          <div className="bg-white/70 rounded-lg p-4">
            <h4 className="font-semibold text-gray-800 mb-2">Próximos Passos</h4>
            <p className="text-sm text-gray-700">
              Mantenha o registro diário para identificar padrões e melhorar o tratamento.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PainDashboard;
// AI_GENERATED_CODE_END