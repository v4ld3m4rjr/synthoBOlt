// [AI Generated] Data: 04/01/2025
// Descrição: Componente de mapa corporal interativo com pontos clicáveis
// Gerado por: Cursor AI
// Versão: React 18.3.1, TypeScript 5.5.3
// AI_GENERATED_CODE_START
import React from 'react';

interface BodyMapProps {
  view: 'front' | 'back';
  selectedBodyParts: string[];
  painData: { [key: string]: number };
  onBodyPartClick: (bodyPart: string) => void;
  onPainChange: (bodyPart: string, value: number) => void;
}

const BodyMap: React.FC<BodyMapProps> = ({
  view,
  selectedBodyParts,
  painData,
  onBodyPartClick,
  onPainChange
}) => {
  // Pontos do corpo para vista frontal
  const frontBodyParts = [
    { id: 'head-front', name: 'Cabeça', x: 50, y: 8 },
    { id: 'neck-front', name: 'Pescoço', x: 50, y: 15 },
    { id: 'shoulder-left', name: 'Ombro Esquerdo', x: 35, y: 22 },
    { id: 'shoulder-right', name: 'Ombro Direito', x: 65, y: 22 },
    { id: 'chest-left', name: 'Peito Esquerdo', x: 42, y: 28 },
    { id: 'chest-right', name: 'Peito Direito', x: 58, y: 28 },
    { id: 'arm-left-upper', name: 'Braço Esquerdo Superior', x: 25, y: 32 },
    { id: 'arm-right-upper', name: 'Braço Direito Superior', x: 75, y: 32 },
    { id: 'abdomen-upper', name: 'Abdome Superior', x: 50, y: 35 },
    { id: 'arm-left-lower', name: 'Antebraço Esquerdo', x: 20, y: 42 },
    { id: 'arm-right-lower', name: 'Antebraço Direito', x: 80, y: 42 },
    { id: 'abdomen-lower', name: 'Abdome Inferior', x: 50, y: 42 },
    { id: 'hip-left', name: 'Quadril Esquerdo', x: 45, y: 48 },
    { id: 'hip-right', name: 'Quadril Direito', x: 55, y: 48 },
    { id: 'hand-left', name: 'Mão Esquerda', x: 15, y: 50 },
    { id: 'hand-right', name: 'Mão Direita', x: 85, y: 50 },
    { id: 'thigh-left-front', name: 'Coxa Esquerda Frontal', x: 45, y: 58 },
    { id: 'thigh-right-front', name: 'Coxa Direita Frontal', x: 55, y: 58 },
    { id: 'knee-left', name: 'Joelho Esquerdo', x: 45, y: 68 },
    { id: 'knee-right', name: 'Joelho Direito', x: 55, y: 68 },
    { id: 'shin-left', name: 'Canela Esquerda', x: 45, y: 78 },
    { id: 'shin-right', name: 'Canela Direita', x: 55, y: 78 },
    { id: 'foot-left', name: 'Pé Esquerdo', x: 45, y: 88 },
    { id: 'foot-right', name: 'Pé Direito', x: 55, y: 88 }
  ];

  // Pontos do corpo para vista traseira
  const backBodyParts = [
    { id: 'head-back', name: 'Nuca', x: 50, y: 8 },
    { id: 'neck-back', name: 'Pescoço Posterior', x: 50, y: 15 },
    { id: 'shoulder-blade-left', name: 'Omoplata Esquerda', x: 40, y: 25 },
    { id: 'shoulder-blade-right', name: 'Omoplata Direita', x: 60, y: 25 },
    { id: 'upper-back-left', name: 'Costas Superior Esquerda', x: 45, y: 30 },
    { id: 'upper-back-right', name: 'Costas Superior Direita', x: 55, y: 30 },
    { id: 'arm-back-left', name: 'Braço Posterior Esquerdo', x: 25, y: 32 },
    { id: 'arm-back-right', name: 'Braço Posterior Direito', x: 75, y: 32 },
    { id: 'middle-back', name: 'Costas Médias', x: 50, y: 38 },
    { id: 'lower-back', name: 'Lombar', x: 50, y: 45 },
    { id: 'glute-left', name: 'Glúteo Esquerdo', x: 45, y: 52 },
    { id: 'glute-right', name: 'Glúteo Direito', x: 55, y: 52 },
    { id: 'thigh-left-back', name: 'Coxa Posterior Esquerda', x: 45, y: 62 },
    { id: 'thigh-right-back', name: 'Coxa Posterior Direita', x: 55, y: 62 },
    { id: 'calf-left', name: 'Panturrilha Esquerda', x: 45, y: 75 },
    { id: 'calf-right', name: 'Panturrilha Direita', x: 55, y: 75 },
    { id: 'achilles-left', name: 'Tendão de Aquiles Esquerdo', x: 45, y: 85 },
    { id: 'achilles-right', name: 'Tendão de Aquiles Direito', x: 55, y: 85 }
  ];

  const currentBodyParts = view === 'front' ? frontBodyParts : backBodyParts;

  const getPainColor = (painLevel: number): string => {
    if (painLevel === 0) return '#E5E7EB'; // gray-200
    if (painLevel <= 3) return '#FEF3C7'; // yellow-100
    if (painLevel <= 6) return '#FED7AA'; // orange-200
    if (painLevel <= 8) return '#FECACA'; // red-200
    return '#DC2626'; // red-600
  };

  const getPainBorderColor = (painLevel: number): string => {
    if (painLevel === 0) return '#9CA3AF'; // gray-400
    if (painLevel <= 3) return '#F59E0B'; // yellow-500
    if (painLevel <= 6) return '#EA580C'; // orange-600
    if (painLevel <= 8) return '#DC2626'; // red-600
    return '#991B1B'; // red-800
  };

  return (
    <div className="relative">
      {/* Corpo Humano SVG */}
      <div className="relative bg-gray-50 rounded-lg p-4 md:p-8">
        <svg
          viewBox="0 0 100 100"
          className="w-full h-96 md:h-[500px] mx-auto"
          style={{ maxWidth: '400px' }}
        >
          {/* Silhueta do corpo */}
          {view === 'front' ? (
            // Vista frontal
            <g>
              {/* Cabeça */}
              <ellipse cx="50" cy="10" rx="8" ry="10" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Pescoço */}
              <rect x="47" y="18" width="6" height="6" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Tronco */}
              <ellipse cx="50" cy="38" rx="18" ry="20" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Braços */}
              <ellipse cx="25" cy="35" rx="4" ry="15" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              <ellipse cx="75" cy="35" rx="4" ry="15" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Antebraços */}
              <ellipse cx="20" cy="50" rx="3" ry="12" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              <ellipse cx="80" cy="50" rx="3" ry="12" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Quadris */}
              <ellipse cx="50" cy="55" rx="12" ry="8" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Coxas */}
              <ellipse cx="45" cy="70" rx="5" ry="15" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              <ellipse cx="55" cy="70" rx="5" ry="15" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Canelas */}
              <ellipse cx="45" cy="88" rx="4" ry="12" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              <ellipse cx="55" cy="88" rx="4" ry="12" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
            </g>
          ) : (
            // Vista traseira
            <g>
              {/* Cabeça */}
              <ellipse cx="50" cy="10" rx="8" ry="10" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Pescoço */}
              <rect x="47" y="18" width="6" height="6" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Tronco */}
              <ellipse cx="50" cy="38" rx="18" ry="20" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Braços */}
              <ellipse cx="25" cy="35" rx="4" ry="15" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              <ellipse cx="75" cy="35" rx="4" ry="15" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Quadris */}
              <ellipse cx="50" cy="55" rx="12" ry="8" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Coxas */}
              <ellipse cx="45" cy="70" rx="5" ry="15" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              <ellipse cx="55" cy="70" rx="5" ry="15" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              
              {/* Panturrilhas */}
              <ellipse cx="45" cy="88" rx="4" ry="12" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
              <ellipse cx="55" cy="88" rx="4" ry="12" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="0.5" />
            </g>
          )}

          {/* Pontos clicáveis */}
          {currentBodyParts.map((bodyPart) => {
            const painLevel = painData[bodyPart.id] || 0;
            const isSelected = selectedBodyParts.includes(bodyPart.id);
            
            return (
              <g key={bodyPart.id}>
                <circle
                  cx={bodyPart.x}
                  cy={bodyPart.y}
                  r="3"
                  fill={getPainColor(painLevel)}
                  stroke={getPainBorderColor(painLevel)}
                  strokeWidth={isSelected ? "2" : "1"}
                  className="cursor-pointer hover:opacity-80 transition-opacity"
                  onClick={() => onBodyPartClick(bodyPart.id)}
                />
                {painLevel > 0 && (
                  <text
                    x={bodyPart.x}
                    y={bodyPart.y + 1}
                    textAnchor="middle"
                    fontSize="2"
                    fill="white"
                    fontWeight="bold"
                    className="pointer-events-none"
                  >
                    {painLevel}
                  </text>
                )}
              </g>
            );
          })}
        </svg>

        {/* Legenda de cores */}
        <div className="mt-4 flex flex-wrap justify-center gap-2 md:gap-4">
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 rounded-full bg-gray-200 border border-gray-400"></div>
            <span className="text-xs text-gray-600">Sem dor</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 rounded-full bg-yellow-100 border border-yellow-500"></div>
            <span className="text-xs text-gray-600">Leve (1-3)</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 rounded-full bg-orange-200 border border-orange-600"></div>
            <span className="text-xs text-gray-600">Moderada (4-6)</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 rounded-full bg-red-200 border border-red-600"></div>
            <span className="text-xs text-gray-600">Intensa (7-8)</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 rounded-full bg-red-600 border border-red-800"></div>
            <span className="text-xs text-gray-600">Severa (9-10)</span>
          </div>
        </div>
      </div>

      {/* Painel de controle para pontos selecionados */}
      {selectedBodyParts.length > 0 && (
        <div className="mt-4 bg-white rounded-lg border border-gray-200 p-4">
          <h4 className="text-sm font-medium text-gray-800 mb-3">
            Áreas Selecionadas ({selectedBodyParts.length})
          </h4>
          <div className="space-y-2">
            {selectedBodyParts.map(bodyPartId => {
              const bodyPart = currentBodyParts.find(bp => bp.id === bodyPartId);
              const painLevel = painData[bodyPartId] || 0;
              
              return bodyPart ? (
                <div key={bodyPartId} className="flex items-center justify-between space-x-2">
                  <span className="text-sm text-gray-700">{bodyPart.name}</span>
                  <div className="flex items-center space-x-1 flex-shrink-0">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={painLevel}
                      onChange={(e) => onPainChange(bodyPartId, parseInt(e.target.value))}
                      className="w-16 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <span className="text-sm font-medium w-6 text-right">
                      {painLevel}/10
                    </span>
                  </div>
                </div>
              ) : null;
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default BodyMap;
// AI_GENERATED_CODE_END