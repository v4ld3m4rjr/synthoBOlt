// [AI Generated] Data: 04/01/2025
// Descrição: Utilitários para dados vazios/zerados
// Gerado por: Cursor AI
// Versão: React 18.3.1, TypeScript 5.5.3
// AI_GENERATED_CODE_START
export interface EmptyDataPoint {
  date: string;
  value: number;
  label: string;
}

// Função para gerar dados zerados
export const generateEmptyData = (days: number = 7): EmptyDataPoint[] => {
  const data: EmptyDataPoint[] = [];
  const today = new Date();
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    
    data.push({
      date: date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
      value: 0,
      label: `${date.toLocaleDateString('pt-BR')}`
    });
  }
  
  return data;
};

// Métricas vazias para usuário sem dados
export const getEmptyMetrics = () => ({
  recovery: 0,
  energy: 0,
  stress: 0,
  mood: 0,
  sleep: 0,
  motivation: 0,
  focus: 0,
  wellbeing: 0,
  anxiety: 0,
  rpe: 0,
  trimp: 0,
  tss: 0,
  ctl: 0,
  atl: 0,
  tsb: 0,
  monotony: 0
});

// Dados vazios para radar chart
export const getEmptyRadarData = () => [
  { subject: 'Recuperação', A: 0, fullMark: 10 },
  { subject: 'Energia', A: 0, fullMark: 10 },
  { subject: 'Estresse', A: 0, fullMark: 10 },
  { subject: 'Humor', A: 0, fullMark: 10 },
  { subject: 'Sono', A: 0, fullMark: 10 },
  { subject: 'Motivação', A: 0, fullMark: 10 },
];

// Função para verificar se o usuário tem dados
export const hasUserData = (userEmail: string): boolean => {
  if (!userEmail) return false;
  
  try {
    const savedData = localStorage.getItem(`recovery_data_${userEmail}`);
    return savedData !== null;
  } catch (error) {
    console.error('Erro ao verificar dados do usuário:', error);
    return false;
  }
};

// Função para carregar dados reais do usuário
export const loadUserRecoveryData = (userEmail: string) => {
  if (!userEmail) return null;
  
  try {
    const savedData = localStorage.getItem(`recovery_data_${userEmail}`);
    if (savedData) {
      return JSON.parse(savedData);
    }
    return null;
  } catch (error) {
    console.error('Erro ao carregar dados do usuário:', error);
    return null;
  }
};

// Função para obter status baseado em valor zero
export const getEmptyStatus = (metricType: string): string => {
  switch (metricType) {
    case 'recovery':
    case 'energy':
    case 'mood':
    case 'sleep':
    case 'motivation':
    case 'focus':
    case 'wellbeing':
      return 'Sem dados';
    case 'stress':
    case 'anxiety':
      return 'Não avaliado';
    default:
      return 'Não registrado';
  }
};

// Função para obter cor para valores zerados
export const getEmptyValueColor = (): string => {
  return '#9CA3AF'; // gray-400
};

// Tooltip customizado para dados vazios
export const EmptyTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
        <p className="text-sm font-medium text-gray-600 mb-2">{`Data: ${label}`}</p>
        <p className="text-sm text-gray-500">Nenhum dado registrado</p>
      </div>
    );
  }
  return null;
};
// AI_GENERATED_CODE_END