// Utilitários para normalização e processamento de dados
export interface DataPoint {
  date: string;
  value: number;
  label: string;
}

export interface NormalizedData {
  normalized: number;
  original: number;
  unit: string;
}

// Função para normalizar dados para escala 0-10
export const normalizeToScale = (value: number, min: number, max: number): number => {
  if (max === min) return 5; // Valor médio se não há variação
  const normalized = ((value - min) / (max - min)) * 10;
  return Math.max(0, Math.min(10, normalized));
};

// Configurações de normalização por tipo de dado
export const normalizationConfig = {
  trimp: { min: 0, max: 500, unit: 'TRIMP' },
  tss: { min: 0, max: 300, unit: 'TSS' },
  rpe: { min: 0, max: 10, unit: 'RPE' },
  recovery: { min: 0, max: 10, unit: '/10' },
  energy: { min: 0, max: 10, unit: '/10' },
  mood: { min: 0, max: 10, unit: '/10' },
  stress: { min: 0, max: 10, unit: '/10' },
  sleep: { min: 0, max: 10, unit: '/10' },
  motivation: { min: 0, max: 10, unit: '/10' },
  focus: { min: 0, max: 10, unit: '/10' },
  wellbeing: { min: 0, max: 10, unit: '/10' },
  anxiety: { min: 0, max: 10, unit: '/10' },
  monotony: { min: 0, max: 5, unit: 'Monotonia' },
  ctl: { min: 0, max: 200, unit: 'CTL' },
  atl: { min: 0, max: 150, unit: 'ATL' },
  tsb: { min: -50, max: 50, unit: 'TSB' },
};

// Função para normalizar um valor específico
export const normalizeValue = (value: number, type: keyof typeof normalizationConfig): NormalizedData => {
  const config = normalizationConfig[type];
  return {
    normalized: normalizeToScale(value, config.min, config.max),
    original: value,
    unit: config.unit
  };
};

// Gerador de dados mockados para demonstração com datas reais
export const generateMockData = (days: number = 7): DataPoint[] => {
  const data: DataPoint[] = [];
  const today = new Date();
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    
    data.push({
      date: date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
      value: Math.random() * 10,
      label: `${date.toLocaleDateString('pt-BR')}`
    });
  }
  
  return data;
};

// Cores para os gráficos e cards
export const chartColors = {
  primary: '#3B82F6',      // Azul
  secondary: '#10B981',    // Verde
  accent: '#F59E0B',       // Amarelo
  danger: '#EF4444',       // Vermelho
  warning: '#F97316',      // Laranja
  info: '#06B6D4',         // Ciano
  success: '#22C55E',      // Verde claro
  purple: '#8B5CF6',       // Roxo
  pink: '#EC4899',         // Rosa
  indigo: '#6366F1',       // Índigo
  teal: '#14B8A6',         // Verde-azulado
  emerald: '#059669',      // Esmeralda
};

// Cores específicas para cada card
export const cardColors = {
  dashboard: {
    primary: '#3B82F6',
    bg: 'from-blue-50 to-indigo-50',
    border: 'border-blue-200',
    hover: 'hover:border-blue-300'
  },
  recovery: {
    primary: '#10B981',
    bg: 'from-green-50 to-emerald-50',
    border: 'border-green-200',
    hover: 'hover:border-green-300'
  },
  training: {
    primary: '#F97316',
    bg: 'from-orange-50 to-red-50',
    border: 'border-orange-200',
    hover: 'hover:border-orange-300'
  },
  ai: {
    primary: '#8B5CF6',
    bg: 'from-purple-50 to-pink-50',
    border: 'border-purple-200',
    hover: 'hover:border-purple-300'
  },
  analytics: {
    primary: '#06B6D4',
    bg: 'from-cyan-50 to-blue-50',
    border: 'border-cyan-200',
    hover: 'hover:border-cyan-300'
  }
};

// Função para obter cor baseada no valor (0-10)
export const getValueColor = (value: number): string => {
  if (value >= 8) return chartColors.success;
  if (value >= 6) return chartColors.primary;
  if (value >= 4) return chartColors.warning;
  return chartColors.danger;
};

// Tooltip customizado para gráficos
export const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
        <p className="text-sm font-medium text-gray-600 mb-2">{`Data: ${label}`}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-sm" style={{ color: entry.color }}>
            {`${entry.name}: ${entry.value.toFixed(1)}/10`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};