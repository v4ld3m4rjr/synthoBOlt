import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import Navbar from './components/Navigation/Navbar';
import MainDashboard from './components/Dashboard/MainDashboard';
import CoachDashboard from './components/Dashboard/CoachDashboard';
import RecoveryPage from './pages/RecoveryPage';
import TrainingPage from './pages/TrainingPage';
import AIAnalysisPage from './pages/AIAnalysisPage';
import AnalyticsPage from './pages/AnalyticsPage';
import RehabilitationPage from './pages/RehabilitationPage';
import RehabilitationAssessmentPage from './pages/RehabilitationAssessmentPage';
import { useAuth } from './hooks/useAuth';
import { UserProfile } from './hooks/useProfile';

function App() {
  const { isAuthenticated, userProfile, userEmail, login, register, logout } = useAuth();

  const handleLogin = (profile: UserProfile, credentials: { email: string; password: string }) => {
    try {
      login(profile, credentials);
    } catch (error) {
      throw error; // Repassar erro para o componente de login
    }
  };

  const handleRegister = (profile: UserProfile, userData: { email: string; password: string; name: string }) => {
    try {
      console.log('App: Iniciando registro para:', userData.email);
      register(profile, userData);
      console.log('App: Registro concluído com sucesso');
    } catch (error) {
      console.error('App: Erro no registro:', error);
      throw error; // Repassar erro para o componente de login
    }
  };

  if (!isAuthenticated) {
    return <LoginForm onLogin={handleLogin} onRegister={handleRegister} />;
  }

  // Renderizar dashboard específico baseado no perfil
  const renderDashboard = () => {
    if (userProfile === 'coach') {
      return <CoachDashboard userEmail={userEmail} />;
    }
    return <MainDashboard userEmail={userEmail} />;
  };

  return (
    <Router>
      <Navbar userProfile={userProfile!} onLogout={logout} />
      <Routes>
        <Route path="/" element={renderDashboard()} />
        <Route path="/recovery" element={<RecoveryPage userEmail={userEmail} />} />
        <Route path="/training" element={<TrainingPage userEmail={userEmail} />} />
        <Route path="/ai-analysis" element={<AIAnalysisPage userEmail={userEmail} />} />
        <Route path="/analytics" element={<AnalyticsPage userEmail={userEmail} />} />
        <Route path="/rehabilitation" element={<RehabilitationPage userEmail={userEmail} />} />
        <Route path="/rehabilitation-assessment" element={<RehabilitationAssessmentPage userEmail={userEmail} />} />
      </Routes>
    </Router>
  );
}

export default App;