// [AI Generated] Data: 04/01/2025
// Descrição: Página de Reabilitação & Dor com mapa corporal interativo
// Gerado por: Cursor AI
// Versão: React 18.3.1, TypeScript 5.5.3
// AI_GENERATED_CODE_START
import React, { useState } from 'react';
import { Save, RotateCcw, Eye, EyeOff, TrendingUp, AlertTriangle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip, ScatterChart, Scatter, BarChart, Bar } from 'recharts';
import { generateEmptyData, hasUserData, EmptyTooltip } from '../utils/emptyDataUtils';
import { CustomTooltip, chartColors } from '../utils/dataUtils';
import BodyMap from '../components/Rehabilitation/BodyMap';
import PainDashboard from '../components/Rehabilitation/PainDashboard';

interface RehabilitationPageProps {
  userEmail: string | null;
}

interface PainData {
  [key: string]: number; // 0-10 scale
}

interface CorrelationData {
  stress: number;
  sleep: number;
  mood: number;
  recovery: number;
  training: number;
  weather: number;
  hydration: number;
  nutrition: number;
}

const RehabilitationPage: React.FC<RehabilitationPageProps> = ({ userEmail }) => {
  const hasData = hasUserData(userEmail || '');
  const [activeView, setActiveView] = useState<'front' | 'back'>('front');
  const [selectedBodyParts, setSelectedBodyParts] = useState<string[]>([]);
  const [painData, setPainData] = useState<PainData>({});
  const [correlationData, setCorrelationData] = useState<CorrelationData>({
    stress: 0,
    sleep: 0,
    mood: 0,
    recovery: 0,
    training: 0,
    weather: 0,
    hydration: 0,
    nutrition: 0
  });
  const [showDashboard, setShowDashboard] = useState(false);

  // Grupos musculares organizados por região
  const muscleGroups = {
    head: ['Temporal', 'Masseter', 'Cervical Superior'],
    neck: ['Esternocleidomastoideo', 'Trapézio Superior', 'Escalenos'],
    shoulders: ['Deltóide Anterior', 'Deltóide Médio', 'Deltóide Posterior', 'Trapézio Médio'],
    arms: ['Bíceps', 'Tríceps', 'Braquial', 'Antebraço Flexores', 'Antebraço Extensores'],
    chest: ['Peitoral Maior', 'Peitoral Menor', 'Serrátil Anterior'],
    back: ['Latíssimo do Dorso', 'Rombóides', 'Trapézio Inferior', 'Eretor da Espinha'],
    core: ['Reto Abdominal', 'Oblíquos', 'Transverso do Abdome', 'Quadrado Lombar'],
    hips: ['Glúteo Máximo', 'Glúteo Médio', 'Glúteo Mínimo', 'Piriforme'],
    thighs: ['Quadríceps', 'Isquiotibiais', 'Adutores', 'Tensor da Fáscia Lata'],
    calves: ['Gastrocnêmio', 'Sóleo', 'Tibial Anterior', 'Fibulares']
  };

  // Articulações principais
  const joints = [
    'Temporomandibular (ATM)', 'Cervical', 'Ombro Direito', 'Ombro Esquerdo',
    'Cotovelo Direito', 'Cotovelo Esquerdo', 'Punho Direito', 'Punho Esquerdo',
    'Coluna Torácica', 'Coluna Lombar', 'Quadril Direito', 'Quadril Esquerdo',
    'Joelho Direito', 'Joelho Esquerdo', 'Tornozelo Direito', 'Tornozelo Esquerdo',
    'Sacroilíaca Direita', 'Sacroilíaca Esquerda'
  ];

  const handleBodyPartClick = (bodyPart: string) => {
    setSelectedBodyParts(prev => 
      prev.includes(bodyPart) 
        ? prev.filter(part => part !== bodyPart)
        : [...prev, bodyPart]
    );
  };

  const handlePainChange = (bodyPart: string, value: number) => {
    setPainData(prev => ({ ...prev, [bodyPart]: value }));
  };

  const handleCorrelationChange = (factor: keyof CorrelationData, value: number) => {
    setCorrelationData(prev => ({ ...prev, [factor]: value }));
  };

  const clearAllData = () => {
    setPainData({});
    setSelectedBodyParts([]);
    setCorrelationData({
      stress: 0,
      sleep: 0,
      mood: 0,
      recovery: 0,
      training: 0,
      weather: 0,
      hydration: 0,
      nutrition: 0
    });
  };

  const handleSave = () => {
    console.log('Salvando dados de dor:', {
      painData,
      correlationData,
      selectedBodyParts,
      timestamp: new Date().toISOString()
    });
    // Aqui você salvaria os dados no backend
  };

  const getPainLevel = (value: number): { text: string; color: string } => {
    if (value === 0) return { text: 'Sem dor', color: 'text-green-600' };
    if (value <= 3) return { text: 'Leve', color: 'text-yellow-600' };
    if (value <= 6) return { text: 'Moderada', color: 'text-orange-600' };
    if (value <= 8) return { text: 'Intensa', color: 'text-red-600' };
    return { text: 'Severa', color: 'text-red-800' };
  };

  const getAveragePain = (): number => {
    const values = Object.values(painData).filter(v => v > 0);
    return values.length > 0 ? values.reduce((sum, val) => sum + val, 0) / values.length : 0;
  };

  const getHighestPainAreas = (): Array<{ area: string; value: number }> => {
    return Object.entries(painData)
      .filter(([_, value]) => value > 0)
      .sort(([_, a], [__, b]) => b - a)
      .slice(0, 5)
      .map(([area, value]) => ({ area, value }));
  };

  // Dados para correlação (simulados)
  const correlationChartData = Object.entries(correlationData).map(([factor, value]) => ({
    factor: factor.charAt(0).toUpperCase() + factor.slice(1),
    value,
    pain: getAveragePain()
  }));

  // Dados de evolução da dor (simulados)
  const painEvolutionData = generateEmptyData(7).map((point, index) => ({
    ...point,
    pain: Math.max(0, getAveragePain() + (Math.random() - 0.5) * 2),
    stress: correlationData.stress + (Math.random() - 0.5) * 2,
    sleep: correlationData.sleep + (Math.random() - 0.5) * 2
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 p-2 md:p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-4 md:mb-6">
          <div className="text-center md:text-left">
            <h1 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">
              Reabilitação & Monitoramento de Dor
            </h1>
            <p className="text-sm md:text-base text-gray-600">
              Mapeie suas dores e analise correlações com fatores externos
            </p>
          </div>
        </div>

        {/* Toggle Dashboard */}
        <div className="mb-4 md:mb-6 flex justify-center">
          <div className="flex bg-white rounded-lg p-1 shadow-md">
            <button
              onClick={() => setShowDashboard(false)}
              className={`px-3 md:px-4 py-2 rounded-md text-xs md:text-sm font-medium transition-colors ${
                !showDashboard 
                  ? 'bg-red-600 text-white' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Mapa Corporal
            </button>
            <button
              onClick={() => setShowDashboard(true)}
              className={`px-3 md:px-4 py-2 rounded-md text-xs md:text-sm font-medium transition-colors ${
                showDashboard 
                  ? 'bg-red-600 text-white' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Dashboard de Análise
            </button>
          </div>
        </div>

        {!showDashboard ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 md:gap-6">
            {/* Mapa Corporal */}
            <div className="lg:col-span-8 bg-white rounded-xl shadow-lg p-4 md:p-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 md:mb-6">
                <h2 className="text-lg md:text-xl font-semibold text-gray-800 mb-3 md:mb-0">
                  Mapa Corporal Interativo
                </h2>
                <div className="flex items-center space-x-2">
                  <div className="flex bg-gray-100 rounded-lg p-1">
                    <button
                      onClick={() => setActiveView('front')}
                      className={`px-3 py-1 rounded-md text-xs md:text-sm font-medium transition-colors ${
                        activeView === 'front' 
                          ? 'bg-white text-gray-900 shadow-sm' 
                          : 'text-gray-600'
                      }`}
                    >
                      Frente
                    </button>
                    <button
                      onClick={() => setActiveView('back')}
                      className={`px-3 py-1 rounded-md text-xs md:text-sm font-medium transition-colors ${
                        activeView === 'back' 
                          ? 'bg-white text-gray-900 shadow-sm' 
                          : 'text-gray-600'
                      }`}
                    >
                      Costas
                    </button>
                  </div>
                  <button
                    onClick={clearAllData}
                    className="flex items-center space-x-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                  >
                    <RotateCcw className="h-3 w-3" />
                    <span className="text-xs md:text-sm">Limpar</span>
                  </button>
                </div>
              </div>

              <BodyMap
                view={activeView}
                selectedBodyParts={selectedBodyParts}
                painData={painData}
                onBodyPartClick={handleBodyPartClick}
                onPainChange={handlePainChange}
              />
            </div>

            {/* Painel Lateral */}
            <div className="lg:col-span-4 space-y-4 md:space-y-6">
              {/* Grupos Musculares */}
              <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
                <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4">
                  Grupos Musculares
                </h3>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {Object.entries(muscleGroups).map(([region, muscles]) => (
                    <div key={region} className="border-b border-gray-100 pb-3">
                      <h4 className="text-sm font-medium text-gray-700 mb-2 capitalize">
                        {region === 'head' ? 'Cabeça' : 
                         region === 'neck' ? 'Pescoço' :
                         region === 'shoulders' ? 'Ombros' :
                         region === 'arms' ? 'Braços' :
                         region === 'chest' ? 'Peito' :
                         region === 'back' ? 'Costas' :
                         region === 'core' ? 'Core' :
                         region === 'hips' ? 'Quadris' :
                         region === 'thighs' ? 'Coxas' :
                         region === 'calves' ? 'Panturrilhas' : region}
                      </h4>
                      <div className="grid grid-cols-1 gap-1">
                        {muscles.map(muscle => (
                          <div key={muscle} className="flex items-center justify-between space-x-2">
                            <span className="text-xs text-gray-600">{muscle}</span>
                            <div className="flex items-center space-x-1 flex-shrink-0">
                              <input
                                type="range"
                                min="0"
                                max="10"
                                value={painData[muscle] || 0}
                                onChange={(e) => handlePainChange(muscle, parseInt(e.target.value))}
                                className="w-12 h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                              />
                              <span className="text-xs font-medium w-4 text-right">
                                {painData[muscle] || 0}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Articulações */}
              <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
                <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4">
                  Articulações
                </h3>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {joints.map(joint => (
                    <div key={joint} className="flex items-center justify-between space-x-2">
                      <span className="text-xs text-gray-600">{joint}</span>
                      <div className="flex items-center space-x-1 flex-shrink-0">
                        <input
                          type="range"
                          min="0"
                          max="10"
                          value={painData[joint] || 0}
                          onChange={(e) => handlePainChange(joint, parseInt(e.target.value))}
                          className="w-12 h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                        />
                        <span className="text-xs font-medium w-4 text-right">
                          {painData[joint] || 0}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Fatores Correlacionados */}
              <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
                <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4">
                  Fatores Relacionados
                </h3>
                <div className="space-y-3">
                  {Object.entries(correlationData).map(([factor, value]) => (
                    <div key={factor}>
                      <label className="block text-xs font-medium text-gray-700 mb-1 capitalize">
                        {factor === 'stress' ? 'Estresse' :
                         factor === 'sleep' ? 'Qualidade do Sono' :
                         factor === 'mood' ? 'Humor' :
                         factor === 'recovery' ? 'Recuperação' :
                         factor === 'training' ? 'Intensidade do Treino' :
                         factor === 'weather' ? 'Clima/Temperatura' :
                         factor === 'hydration' ? 'Hidratação' :
                         factor === 'nutrition' ? 'Nutrição' : factor}
                      </label>
                      <div className="flex items-center space-x-2">
                        <input
                          type="range"
                          min="0"
                          max="10"
                          value={value}
                          onChange={(e) => handleCorrelationChange(factor as keyof CorrelationData, parseInt(e.target.value))}
                          className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                        />
                        <span className="text-sm font-medium w-8 text-right">
                          {value}/10
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Resumo Rápido */}
              <div className="bg-gradient-to-br from-red-50 to-pink-50 rounded-xl p-4 md:p-6">
                <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4">
                  Resumo da Sessão
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Dor Média</span>
                    <span className={`font-semibold ${getPainLevel(getAveragePain()).color}`}>
                      {getAveragePain().toFixed(1)}/10
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Áreas Afetadas</span>
                    <span className="font-semibold text-red-600">
                      {Object.values(painData).filter(v => v > 0).length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Nível Geral</span>
                    <span className={`font-semibold ${getPainLevel(getAveragePain()).color}`}>
                      {getPainLevel(getAveragePain()).text}
                    </span>
                  </div>
                </div>
              </div>

              {/* Botão Salvar */}
              <button
                onClick={handleSave}
                className="w-full flex items-center justify-center space-x-2 bg-red-600 text-white px-4 py-3 rounded-lg hover:bg-red-700 transition-colors"
              >
                <div className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center">
                  <Save className="h-3 w-3" />
                </div>
                <span>Salvar Avaliação</span>
              </button>
            </div>
          </div>
        ) : (
          <PainDashboard
            painData={painData}
            correlationData={correlationData}
            painEvolutionData={painEvolutionData}
            correlationChartData={correlationChartData}
            getHighestPainAreas={getHighestPainAreas}
            getAveragePain={getAveragePain}
            getPainLevel={getPainLevel}
          />
        )}
      </div>
    </div>
  );
};

export default RehabilitationPage;
// AI_GENERATED_CODE_END