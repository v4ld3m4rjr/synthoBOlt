import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, BarChart3, TrendingUp, Filter, Download, Eye, EyeOff } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, ScatterChart, Scatter, BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from 'recharts';
import { generateMockData, normalizeValue, getValueColor, chartColors, CustomTooltip } from '../utils/dataUtils';
import { loadUserRecoveryData, generateEmptyData, EmptyTooltip } from '../utils/emptyDataUtils';

interface AnalyticsPageProps {
  userEmail: string | null;
}

const AnalyticsPage: React.FC<AnalyticsPageProps> = ({ userEmail }) => {
  const navigate = useNavigate();
  const [selectedVariables, setSelectedVariables] = useState<string[]>(['recovery', 'energy', 'stress', 'mood']);
  const [timeRange, setTimeRange] = useState<string>('7d');
  const [chartType, setChartType] = useState<string>('line');

  // Verificar se o usuário tem dados reais
  const userRecoveryData = loadUserRecoveryData(userEmail || '');
  const hasRealData = userRecoveryData !== null;

  // Todas as variáveis disponíveis (normalizadas para 0-10)
  const allVariables = [
    { key: 'recovery', label: 'Recuperação', color: chartColors.success },
    { key: 'energy', label: 'Energia', color: chartColors.primary },
    { key: 'stress', label: 'Estresse', color: chartColors.danger },
    { key: 'mood', label: 'Humor', color: chartColors.warning },
    { key: 'sleep', label: 'Sono', color: chartColors.purple },
    { key: 'motivation', label: 'Motivação', color: chartColors.accent },
    { key: 'focus', label: 'Foco', color: chartColors.info },
    { key: 'wellbeing', label: 'Bem-estar', color: chartColors.success },
    { key: 'anxiety', label: 'Ansiedade', color: chartColors.danger },
    { key: 'rpe', label: 'RPE', color: chartColors.warning },
    { key: 'trimp', label: 'TRIMP', color: chartColors.primary },
    { key: 'tss', label: 'TSS', color: chartColors.accent },
    { key: 'ctl', label: 'CTL', color: chartColors.info },
    { key: 'atl', label: 'ATL', color: chartColors.warning },
    { key: 'tsb', label: 'TSB', color: chartColors.success },
    { key: 'monotony', label: 'Monotonia', color: chartColors.danger },
  ];

  // Gerar dados para o período selecionado
  const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
  
  const chartData = hasRealData ? generateEmptyData(days).map((point, index) => {
    const data: any = { date: point.date };
    selectedVariables.forEach(variable => {
      // Usar dados reais como base e simular variação histórica
      let baseValue = userRecoveryData[variable] || 0;
      
      // Para o último ponto, usar valor real
      if (index === days - 1) {
        data[variable] = baseValue;
      } else {
        // Para pontos anteriores, simular variação baseada no valor real
        const variation = (Math.random() - 0.5) * 2;
        data[variable] = Math.max(0, Math.min(10, baseValue + variation));
      }
    });
    return data;
  }) : generateMockData(days).map(point => {
    const data: any = { date: point.date };
    selectedVariables.forEach(variable => {
      // Para usuários sem dados, mostrar valores zerados
      data[variable] = 0;
    });
    return data;
  });

  // Dados para correlação apenas se houver dados reais
  const correlationData = hasRealData && selectedVariables.slice(0, 2).length === 2 ? 
    chartData.map(point => ({
      x: point[selectedVariables[0]],
      y: point[selectedVariables[1]]
    })) : [];

  // Dados para radar apenas se houver dados reais
  const radarData = hasRealData ? selectedVariables.slice(0, 6).map(variable => ({
    subject: allVariables.find(v => v.key === variable)?.label || variable,
    A: userRecoveryData[variable] || 0,
    fullMark: 10
  })) : [];

  // Estatísticas apenas se houver dados reais
  const stats = hasRealData ? selectedVariables.map(variable => {
    const values = chartData.map(point => point[variable]).filter(v => v !== undefined);
    const avg = values.reduce((sum, val) => sum + val, 0) / values.length;
    const min = Math.min(...values);
    const max = Math.max(...values);
    const trend = values.length > 1 ? values[values.length - 1] - values[0] : 0;
    
    return {
      variable,
      label: allVariables.find(v => v.key === variable)?.label || variable,
      color: allVariables.find(v => v.key === variable)?.color || chartColors.primary,
      avg: avg.toFixed(1),
      min: min.toFixed(1),
      max: max.toFixed(1),
      trend: trend.toFixed(1),
      current: values[values.length - 1]?.toFixed(1) || '0'
    };
  }) : [];

  const toggleVariable = (variable: string) => {
    setSelectedVariables(prev => 
      prev.includes(variable) 
        ? prev.filter(v => v !== variable)
        : [...prev, variable]
    );
  };

  const renderChart = () => {
    if (!hasRealData) {
      return (
        <div className="h-96 flex items-center justify-center text-gray-500">
          <div className="text-center">
            <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">
              Nenhum dado disponível
            </h3>
            <p className="text-sm text-gray-500 mb-4">
              Registre dados na página de Recuperação para ver análises
            </p>
            <button
              onClick={() => navigate('/recovery')}
              className="px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors"
            >
              Ir para Recuperação
            </button>
          </div>
        </div>
      );
    }

    if (chartType === 'line') {
      return (
        <LineChart data={chartData}>
          <XAxis dataKey="date" />
          <YAxis domain={[0, 10]} />
          <Tooltip content={<CustomTooltip />} />
          {selectedVariables.map(variable => {
            const color = allVariables.find(v => v.key === variable)?.color;
            const label = allVariables.find(v => v.key === variable)?.label;
            return (
              <Line
                key={variable}
                type="monotone"
                dataKey={variable}
                stroke={color}
                strokeWidth={2}
                dot={{ fill: color, r: 3 }}
                name={label}
              />
            );
          })}
        </LineChart>
      );
    } else if (chartType === 'bar') {
      return (
        <BarChart data={chartData}>
          <XAxis dataKey="date" />
          <YAxis domain={[0, 10]} />
          <Tooltip content={<CustomTooltip />} />
          {selectedVariables.map((variable, index) => {
            const color = allVariables.find(v => v.key === variable)?.color;
            const label = allVariables.find(v => v.key === variable)?.label;
            return (
              <Bar
                key={variable}
                dataKey={variable}
                fill={color}
                opacity={0.7}
                name={label}
              />
            );
          })}
        </BarChart>
      );
    } else if (chartType === 'scatter' && correlationData.length > 0) {
      const xLabel = allVariables.find(v => v.key === selectedVariables[0])?.label;
      const yLabel = allVariables.find(v => v.key === selectedVariables[1])?.label;
      return (
        <ScatterChart data={correlationData}>
          <XAxis dataKey="x" domain={[0, 10]} label={{ value: xLabel, position: 'insideBottom', offset: -5 }} />
          <YAxis dataKey="y" domain={[0, 10]} label={{ value: yLabel, angle: -90, position: 'insideLeft' }} />
          <Tooltip content={<CustomTooltip />} />
          <Scatter
            dataKey="y"
            fill={chartColors.primary}
            opacity={0.6}
            name={`${xLabel} vs ${yLabel}`}
          />
        </ScatterChart>
      );
    } else if (chartType === 'radar') {
      return (
        <RadarChart data={radarData}>
          <PolarGrid />
          <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10 }} />
          <PolarRadiusAxis angle={90} domain={[0, 10]} tick={{ fontSize: 8 }} />
          <Tooltip content={<CustomTooltip />} />
          <Radar
            name="Atual"
            dataKey="A"
            stroke={chartColors.primary}
            fill={chartColors.primary}
            fillOpacity={0.3}
            strokeWidth={2}
          />
        </RadarChart>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-lg bg-white shadow-md hover:shadow-lg transition-shadow"
            >
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Dashboard de Análise</h1>
              <p className="text-gray-600">Analise todas as variáveis e descubra correlações</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
            >
              <option value="7d">Últimos 7 dias</option>
              <option value="30d">Últimos 30 dias</option>
              <option value="90d">Últimos 90 dias</option>
            </select>
            <select
              value={chartType}
              onChange={(e) => setChartType(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
            >
              <option value="line">Linha</option>
              <option value="bar">Barras</option>
              <option value="scatter">Dispersão</option>
              <option value="radar">Radar</option>
            </select>
            <button className="flex items-center space-x-2 bg-cyan-600 text-white px-4 py-2 rounded-lg hover:bg-cyan-700 transition-colors">
              <Download className="h-4 w-4" />
              <span>Exportar</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Seletor de Variáveis */}
          <div className="lg:col-span-3 space-y-4">
            <div className="bg-white rounded-xl shadow-lg p-4">
              <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <Filter className="mr-2 h-5 w-5 text-cyan-600" />
                Variáveis ({selectedVariables.length})
              </h2>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {allVariables.map(variable => (
                  <button
                    key={variable.key}
                    onClick={() => toggleVariable(variable.key)}
                    className={`w-full flex items-center justify-between p-3 rounded-lg transition-all duration-200 ${
                      selectedVariables.includes(variable.key)
                        ? 'bg-cyan-50 border-2 border-cyan-200'
                        : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: variable.color }}
                      />
                      <span className="text-sm font-medium text-gray-800">
                        {variable.label}
                      </span>
                    </div>
                    {selectedVariables.includes(variable.key) ? (
                      <Eye className="h-4 w-4 text-cyan-600" />
                    ) : (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Área Principal */}
          <div className="lg:col-span-9 space-y-6">
            {/* Gráfico Principal */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-800 flex items-center">
                  <BarChart3 className="mr-2 h-5 w-5 text-cyan-600" />
                  Análise Comparativa
                </h2>
                <div className="flex items-center space-x-2">
                  {selectedVariables.slice(0, 6).map(variable => {
                    const color = allVariables.find(v => v.key === variable)?.color;
                    const label = allVariables.find(v => v.key === variable)?.label;
                    return (
                      <div key={variable} className="flex items-center space-x-1">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: color }}
                        />
                        <span className="text-xs text-gray-600">{label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {selectedVariables.length > 0 ? (
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    {renderChart()}
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-96 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <p>Selecione variáveis para visualizar o gráfico</p>
                  </div>
                </div>
              )}
            </div>

            {/* Estatísticas */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {stats.map(stat => (
                <div key={stat.variable} className="bg-white rounded-xl shadow-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-gray-600">{stat.label}</h3>
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: stat.color }}
                    />
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Atual</span>
                      <span className="font-semibold" style={{ color: stat.color }}>
                        {stat.current}/10
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Média</span>
                      <span className="font-medium">{stat.avg}/10</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Tendência</span>
                      <span className={`font-medium ${
                        parseFloat(stat.trend) > 0 ? 'text-green-600' : 
                        parseFloat(stat.trend) < 0 ? 'text-red-600' : 'text-gray-600'
                      }`}>
                        {parseFloat(stat.trend) > 0 ? '+' : ''}{stat.trend}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Correlações */}
            {selectedVariables.length >= 2 && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                  <TrendingUp className="mr-2 h-5 w-5 text-green-600" />
                  Correlações Detectadas
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {selectedVariables.slice(0, 3).map((var1, i) => 
                    selectedVariables.slice(i + 1, i + 2).map(var2 => {
                      const correlation = (Math.random() - 0.5) * 2; // Simulação
                      const label1 = allVariables.find(v => v.key === var1)?.label;
                      const label2 = allVariables.find(v => v.key === var2)?.label;
                      
                      return (
                        <div key={`${var1}-${var2}`} className="bg-gray-50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium text-gray-700">
                              {label1} ↔ {label2}
                            </span>
                            <span className={`text-sm font-bold ${
                              correlation > 0.5 ? 'text-green-600' :
                              correlation < -0.5 ? 'text-red-600' : 'text-gray-600'
                            }`}>
                              {correlation > 0 ? '+' : ''}{correlation.toFixed(2)}
                            </span>
                          </div>
                          <div className="text-xs text-gray-500">
                            {Math.abs(correlation) > 0.7 ? 'Correlação forte' :
                             Math.abs(correlation) > 0.3 ? 'Correlação moderada' : 'Correlação fraca'}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;