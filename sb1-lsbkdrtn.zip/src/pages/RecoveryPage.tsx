// [AI Generated] Data: 04/01/2025
// Descrição: Página de Recuperação com persistência de dados e feedback visual
// Gerado por: Cursor AI
// Versão: React 18.3.1, TypeScript 5.5.3
// AI_GENERATED_CODE_START
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, Heart, Brain, Smile, CheckCircle, AlertCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from 'recharts';
import { generateEmptyData, hasUserData, EmptyTooltip } from '../utils/emptyDataUtils';
import { CustomTooltip } from '../utils/dataUtils';

interface RecoveryPageProps {
  userEmail: string | null;
}

interface RecoveryData {
  recovery: number;
  energy: number;
  sleep: number;
  mood: number;
  stress: number;
  motivation: number;
  anxiety: number;
  focus: number;
  wellbeing: number;
  timestamp: string;
}

const RecoveryPage: React.FC<RecoveryPageProps> = ({ userEmail }) => {
  const navigate = useNavigate();
  const hasData = hasUserData(userEmail || '');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  
  const [formData, setFormData] = useState<RecoveryData>({
    recovery: 0,
    energy: 0,
    sleep: 0,
    mood: 0,
    stress: 0,
    motivation: 0,
    anxiety: 0,
    focus: 0,
    wellbeing: 0,
    timestamp: new Date().toISOString()
  });

  // Carregar dados salvos ao montar o componente
  useEffect(() => {
    const loadSavedData = () => {
      try {
        const savedData = localStorage.getItem(`recovery_data_${userEmail}`);
        if (savedData) {
          const parsedData = JSON.parse(savedData);
          setFormData(parsedData);
        }
      } catch (error) {
        console.error('Erro ao carregar dados salvos:', error);
      }
    };

    if (userEmail) {
      loadSavedData();
    }
  }, [userEmail]);

  // Gerar dados históricos baseados nos dados salvos
  const recoveryData = generateEmptyData(7).map((point, index) => ({
    ...point,
    value: index === 6 ? formData.recovery : Math.max(0, formData.recovery + (Math.random() - 0.5) * 2)
  }));
  
  const radarData = [
    { subject: 'Recuperação', A: formData.recovery, fullMark: 10 },
    { subject: 'Energia', A: formData.energy, fullMark: 10 },
    { subject: 'Sono', A: formData.sleep, fullMark: 10 },
    { subject: 'Humor', A: formData.mood, fullMark: 10 },
    { subject: 'Bem-estar', A: formData.wellbeing, fullMark: 10 },
    { subject: 'Foco', A: formData.focus, fullMark: 10 },
  ];

  const handleChange = (field: keyof Omit<RecoveryData, 'timestamp'>, value: number) => {
    setFormData(prev => ({ 
      ...prev, 
      [field]: value,
      timestamp: new Date().toISOString()
    }));
    setSaveStatus('idle'); // Reset status quando dados são alterados
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveStatus('idle');

    try {
      // Simular delay de salvamento
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Salvar no localStorage
      localStorage.setItem(`recovery_data_${userEmail}`, JSON.stringify(formData));
      
      // Salvar histórico
      const historyKey = `recovery_history_${userEmail}`;
      const existingHistory = JSON.parse(localStorage.getItem(historyKey) || '[]');
      const newEntry = {
        ...formData,
        date: new Date().toLocaleDateString('pt-BR')
      };
      
      // Manter apenas os últimos 30 registros
      const updatedHistory = [newEntry, ...existingHistory.slice(0, 29)];
      localStorage.setItem(historyKey, JSON.stringify(updatedHistory));
      
      console.log('Dados salvos com sucesso:', formData);
      setSaveStatus('success');
      
      // Limpar status de sucesso após 3 segundos
      setTimeout(() => {
        setSaveStatus('idle');
      }, 3000);
      
    } catch (error) {
      console.error('Erro ao salvar dados:', error);
      setSaveStatus('error');
      
      // Limpar status de erro após 3 segundos
      setTimeout(() => {
        setSaveStatus('idle');
      }, 3000);
    } finally {
      setIsSaving(false);
    }
  };

  const getFieldStatus = (value: number): { text: string; color: string } => {
    if (value === 0) return { text: 'Não avaliado', color: 'text-gray-500' };
    if (value <= 3) return { text: 'Baixo', color: 'text-red-600' };
    if (value <= 6) return { text: 'Moderado', color: 'text-yellow-600' };
    if (value <= 8) return { text: 'Bom', color: 'text-green-600' };
    return { text: 'Excelente', color: 'text-green-700' };
  };

  const getStressStatus = (value: number): { text: string; color: string } => {
    if (value === 0) return { text: 'Não avaliado', color: 'text-gray-500' };
    if (value <= 3) return { text: 'Baixo', color: 'text-green-600' };
    if (value <= 6) return { text: 'Moderado', color: 'text-yellow-600' };
    if (value <= 8) return { text: 'Alto', color: 'text-red-600' };
    return { text: 'Muito Alto', color: 'text-red-700' };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-2 md:p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-4 md:mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="p-2 rounded-lg bg-white shadow-md hover:shadow-lg transition-shadow"
              >
                <ArrowLeft className="h-5 w-5 text-gray-600" />
              </button>
              <div>
                <h1 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">Recuperação</h1>
                <p className="text-sm md:text-base text-gray-600">Registre seu estado atual de recuperação e bem-estar</p>
              </div>
            </div>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                saveStatus === 'success' 
                  ? 'bg-green-600 text-white' 
                  : saveStatus === 'error'
                  ? 'bg-red-600 text-white'
                  : 'bg-green-600 text-white hover:bg-green-700'
              } ${isSaving ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isSaving ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : saveStatus === 'success' ? (
                <CheckCircle className="h-4 w-4" />
              ) : saveStatus === 'error' ? (
                <AlertCircle className="h-4 w-4" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              <span className="hidden md:inline">
                {isSaving ? 'Salvando...' : saveStatus === 'success' ? 'Salvo!' : saveStatus === 'error' ? 'Erro' : 'Salvar'}
              </span>
            </button>
          </div>
        </div>

        {/* Status de Salvamento */}
        {saveStatus !== 'idle' && (
          <div className={`mb-4 p-3 rounded-lg ${
            saveStatus === 'success' ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
          }`}>
            <div className="flex items-center space-x-2">
              {saveStatus === 'success' ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-600" />
              )}
              <span className={`text-sm font-medium ${
                saveStatus === 'success' ? 'text-green-800' : 'text-red-800'
              }`}>
                {saveStatus === 'success' 
                  ? 'Dados salvos com sucesso!' 
                  : 'Erro ao salvar dados. Tente novamente.'}
              </span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
          {/* Formulário */}
          <div className="lg:col-span-2 space-y-4 md:space-y-6">
            {/* Dados Físicos */}
            <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
              <h2 className="text-base md:text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center mr-2">
                  <Heart className="h-4 w-4 text-green-600" />
                </div>
                Estado Físico
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                  <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Recuperação Geral
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={formData.recovery}
                      onChange={(e) => handleChange('recovery', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs md:text-sm text-gray-500">
                      <span>Péssima</span>
                      <div className="text-center">
                        <span className="font-semibold text-green-600">{formData.recovery}/10</span>
                        <p className={`text-xs ${getFieldStatus(formData.recovery).color}`}>
                          {getFieldStatus(formData.recovery).text}
                        </p>
                      </div>
                      <span>Excelente</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Nível de Energia
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={formData.energy}
                      onChange={(e) => handleChange('energy', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs md:text-sm text-gray-500">
                      <span>Muito Baixa</span>
                      <div className="text-center">
                        <span className="font-semibold text-blue-600">{formData.energy}/10</span>
                        <p className={`text-xs ${getFieldStatus(formData.energy).color}`}>
                          {getFieldStatus(formData.energy).text}
                        </p>
                      </div>
                      <span>Muito Alta</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Qualidade do Sono
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={formData.sleep}
                      onChange={(e) => handleChange('sleep', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs md:text-sm text-gray-500">
                      <span>Péssima</span>
                      <div className="text-center">
                        <span className="font-semibold text-purple-600">{formData.sleep}/10</span>
                        <p className={`text-xs ${getFieldStatus(formData.sleep).color}`}>
                          {getFieldStatus(formData.sleep).text}
                        </p>
                      </div>
                      <span>Excelente</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Nível de Estresse
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={formData.stress}
                      onChange={(e) => handleChange('stress', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs md:text-sm text-gray-500">
                      <span>Nenhum</span>
                      <div className="text-center">
                        <span className="font-semibold text-red-600">{formData.stress}/10</span>
                        <p className={`text-xs ${getStressStatus(formData.stress).color}`}>
                          {getStressStatus(formData.stress).text}
                        </p>
                      </div>
                      <span>Muito Alto</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Dados Psicológicos */}
            <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
              <h2 className="text-base md:text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <div className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center mr-2">
                  <Brain className="h-4 w-4 text-purple-600" />
                </div>
                Estado Psicológico
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                  <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Humor Geral
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={formData.mood}
                      onChange={(e) => handleChange('mood', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs md:text-sm text-gray-500">
                      <span>Péssimo</span>
                      <div className="text-center">
                        <span className="font-semibold text-yellow-600">{formData.mood}/10</span>
                        <p className={`text-xs ${getFieldStatus(formData.mood).color}`}>
                          {getFieldStatus(formData.mood).text}
                        </p>
                      </div>
                      <span>Excelente</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Motivação
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={formData.motivation}
                      onChange={(e) => handleChange('motivation', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs md:text-sm text-gray-500">
                      <span>Nenhuma</span>
                      <div className="text-center">
                        <span className="font-semibold text-orange-600">{formData.motivation}/10</span>
                        <p className={`text-xs ${getFieldStatus(formData.motivation).color}`}>
                          {getFieldStatus(formData.motivation).text}
                        </p>
                      </div>
                      <span>Muito Alta</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Ansiedade
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={formData.anxiety}
                      onChange={(e) => handleChange('anxiety', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs md:text-sm text-gray-500">
                      <span>Nenhuma</span>
                      <div className="text-center">
                        <span className="font-semibold text-red-600">{formData.anxiety}/10</span>
                        <p className={`text-xs ${getStressStatus(formData.anxiety).color}`}>
                          {getStressStatus(formData.anxiety).text}
                        </p>
                      </div>
                      <span>Muito Alta</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Foco/Concentração
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={formData.focus}
                      onChange={(e) => handleChange('focus', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs md:text-sm text-gray-500">
                      <span>Muito Baixo</span>
                      <div className="text-center">
                        <span className="font-semibold text-indigo-600">{formData.focus}/10</span>
                        <p className={`text-xs ${getFieldStatus(formData.focus).color}`}>
                          {getFieldStatus(formData.focus).text}
                        </p>
                      </div>
                      <span>Muito Alto</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bem-estar Geral */}
            <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
              <h2 className="text-base md:text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center mr-2">
                  <Smile className="h-4 w-4 text-green-600" />
                </div>
                Bem-estar Geral
              </h2>
              <div>
                <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                  Como você se sente hoje?
                </label>
                <div className="space-y-2">
                  <input
                    type="range"
                    min="0"
                    max="10"
                    value={formData.wellbeing}
                    onChange={(e) => handleChange('wellbeing', parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-xs md:text-sm text-gray-500">
                    <span>Péssimo</span>
                    <div className="text-center">
                      <span className="font-semibold text-green-600">{formData.wellbeing}/10</span>
                      <p className={`text-xs ${getFieldStatus(formData.wellbeing).color}`}>
                        {getFieldStatus(formData.wellbeing).text}
                      </p>
                    </div>
                    <span>Excelente</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Gráficos e Resumo */}
          <div className="space-y-4 md:space-y-6">
            {/* Evolução dos Últimos 7 Dias */}
            <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
              <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4">
                Evolução - 7 Dias
              </h3>
              <div className="h-32 md:h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={recoveryData}>
                    <XAxis dataKey="date" hide />
                    <YAxis domain={[0, 10]} hide />
                    <Tooltip content={<CustomTooltip />} />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#10B981"
                      strokeWidth={2}
                      dot={{ fill: '#10B981', r: 4 }}
                      name="Recuperação"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Estado Atual - Radar */}
            <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
              <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4">
                Estado Atual
              </h3>
              <div className="h-32 md:h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" tick={{ fontSize: 8 }} />
                    <PolarRadiusAxis angle={90} domain={[0, 10]} tick={{ fontSize: 6 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Radar
                      name="Atual"
                      dataKey="A"
                      stroke="#10B981"
                      fill="#10B981"
                      fillOpacity={0.3}
                      strokeWidth={2}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Resumo Rápido */}
            <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-xl p-4 md:p-6">
              <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-4">
                Resumo Rápido
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs md:text-sm text-gray-600">Recuperação Geral</span>
                  <div className="text-right">
                    <span className="font-semibold text-green-600">{formData.recovery}/10</span>
                    <p className={`text-xs ${getFieldStatus(formData.recovery).color}`}>
                      {getFieldStatus(formData.recovery).text}
                    </p>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs md:text-sm text-gray-600">Estado Mental</span>
                  <div className="text-right">
                    <span className="font-semibold text-blue-600">
                      {((formData.mood + formData.focus + formData.wellbeing) / 3).toFixed(1)}/10
                    </span>
                    <p className={`text-xs ${getFieldStatus((formData.mood + formData.focus + formData.wellbeing) / 3).color}`}>
                      {getFieldStatus((formData.mood + formData.focus + formData.wellbeing) / 3).text}
                    </p>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs md:text-sm text-gray-600">Qualidade do Sono</span>
                  <div className="text-right">
                    <span className="font-semibold text-purple-600">{formData.sleep}/10</span>
                    <p className={`text-xs ${getFieldStatus(formData.sleep).color}`}>
                      {getFieldStatus(formData.sleep).text}
                    </p>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs md:text-sm text-gray-600">Nível de Estresse</span>
                  <div className="text-right">
                    <span className="font-semibold text-red-600">{formData.stress}/10</span>
                    <p className={`text-xs ${getStressStatus(formData.stress).color}`}>
                      {getStressStatus(formData.stress).text}
                    </p>
                  </div>
                </div>
              </div>
              
              {formData.timestamp && (
                <div className="mt-4 pt-3 border-t border-gray-200">
                  <p className="text-xs text-gray-500">
                    Última atualização: {new Date(formData.timestamp).toLocaleString('pt-BR')}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecoveryPage;
// AI_GENERATED_CODE_END