import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, Activity, Timer, Target, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, BarChart, Bar, AreaChart, Area } from 'recharts';
import { generateMockData, normalizeValue } from '../utils/dataUtils';

const TrainingPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    rpe: 6,
    duration: 90,
    trimp: 245,
    tss: 165,
    trainingType: 'endurance',
    heartRateAvg: 145,
    heartRateMax: 170,
    power: 250,
    notes: ''
  });

  const trainingData = generateMockData(7);
  
  // Cálculos derivados
  const ctl = 42; // Chronic Training Load
  const atl = 38; // Acute Training Load
  const tsb = ctl - atl; // Training Stress Balance
  const monotony = 1.8; // Monotonia
  const strain = formData.trimp * monotony; // Strain

  const metricsData = [
    { name: 'TRIMP', value: normalizeValue(formData.trimp, 'trimp').normalized, original: formData.trimp },
    { name: 'TSS', value: normalizeValue(formData.tss, 'tss').normalized, original: formData.tss },
    { name: 'RPE', value: formData.rpe, original: formData.rpe },
    { name: 'CTL', value: normalizeValue(ctl, 'ctl').normalized, original: ctl },
    { name: 'ATL', value: normalizeValue(atl, 'atl').normalized, original: atl },
    { name: 'TSB', value: normalizeValue(tsb, 'tsb').normalized, original: tsb },
  ];

  const handleChange = (field: string, value: number | string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    console.log('Salvando dados de treino:', formData);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-lg bg-white shadow-md hover:shadow-lg transition-shadow"
            >
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Dados de Treino</h1>
              <p className="text-gray-600">Registre sua sessão de treino e métricas de carga</p>
            </div>
          </div>
          <button
            onClick={handleSave}
            className="flex items-center space-x-2 bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors"
          >
            <Save className="h-4 w-4" />
            <span>Salvar Treino</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Formulário Principal */}
          <div className="lg:col-span-8 space-y-6">
            {/* Dados Básicos do Treino */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <Activity className="mr-2 h-5 w-5 text-orange-600" />
                Dados Básicos
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    RPE (Percepção de Esforço)
                  </label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={formData.rpe}
                      onChange={(e) => handleChange('rpe', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>Muito Fácil</span>
                      <span className="font-semibold text-red-600">{formData.rpe}/10</span>
                      <span>Máximo</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Duração (minutos)
                  </label>
                  <input
                    type="number"
                    value={formData.duration}
                    onChange={(e) => handleChange('duration', parseInt(e.target.value))}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    min="1"
                    max="600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Tipo de Treino
                  </label>
                  <select
                    value={formData.trainingType}
                    onChange={(e) => handleChange('trainingType', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  >
                    <option value="endurance">Resistência</option>
                    <option value="strength">Força</option>
                    <option value="interval">Intervalado</option>
                    <option value="recovery">Recuperação</option>
                    <option value="competition">Competição</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    FC Média (bpm)
                  </label>
                  <input
                    type="number"
                    value={formData.heartRateAvg}
                    onChange={(e) => handleChange('heartRateAvg', parseInt(e.target.value))}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    min="60"
                    max="220"
                  />
                </div>
              </div>
            </div>

            {/* Métricas Avançadas */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <Target className="mr-2 h-5 w-5 text-blue-600" />
                Métricas Avançadas
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    TRIMP
                  </label>
                  <input
                    type="number"
                    value={formData.trimp}
                    onChange={(e) => handleChange('trimp', parseInt(e.target.value))}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    min="0"
                    max="1000"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    TSS (Training Stress Score)
                  </label>
                  <input
                    type="number"
                    value={formData.tss}
                    onChange={(e) => handleChange('tss', parseInt(e.target.value))}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    min="0"
                    max="500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    FC Máxima (bpm)
                  </label>
                  <input
                    type="number"
                    value={formData.heartRateMax}
                    onChange={(e) => handleChange('heartRateMax', parseInt(e.target.value))}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    min="60"
                    max="220"
                  />
                </div>
              </div>
            </div>

            {/* Métricas Calculadas */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <TrendingUp className="mr-2 h-5 w-5 text-green-600" />
                Métricas Calculadas
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-blue-50 rounded-lg p-4 text-center">
                  <p className="text-sm text-gray-600">CTL</p>
                  <p className="text-2xl font-bold text-blue-600">{ctl}</p>
                  <p className="text-xs text-gray-500">Carga Crônica</p>
                </div>
                <div className="bg-orange-50 rounded-lg p-4 text-center">
                  <p className="text-sm text-gray-600">ATL</p>
                  <p className="text-2xl font-bold text-orange-600">{atl}</p>
                  <p className="text-xs text-gray-500">Carga Aguda</p>
                </div>
                <div className="bg-green-50 rounded-lg p-4 text-center">
                  <p className="text-sm text-gray-600">TSB</p>
                  <p className="text-2xl font-bold text-green-600">{tsb}</p>
                  <p className="text-xs text-gray-500">Balanço</p>
                </div>
                <div className="bg-purple-50 rounded-lg p-4 text-center">
                  <p className="text-sm text-gray-600">Monotonia</p>
                  <p className="text-2xl font-bold text-purple-600">{monotony}</p>
                  <p className="text-xs text-gray-500">Variabilidade</p>
                </div>
              </div>
            </div>

            {/* Observações */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">
                Observações
              </h2>
              <textarea
                value={formData.notes}
                onChange={(e) => handleChange('notes', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                rows={3}
                placeholder="Adicione observações sobre o treino..."
              />
            </div>
          </div>

          {/* Gráficos e Resumo */}
          <div className="lg:col-span-4 space-y-6">
            {/* Evolução da Carga */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Evolução - 7 Dias
              </h3>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trainingData}>
                    <XAxis dataKey="date" hide />
                    <YAxis domain={[0, 10]} hide />
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="#F97316"
                      fill="#F97316"
                      fillOpacity={0.3}
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Métricas Normalizadas */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Métricas (0-10)
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={metricsData} layout="horizontal">
                    <XAxis type="number" domain={[0, 10]} />
                    <YAxis dataKey="name" type="category" width={40} />
                    <Bar
                      dataKey="value"
                      fill="#F97316"
                      radius={[0, 4, 4, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Análise Rápida */}
            <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Análise Rápida
              </h3>
              <div className="space-y-3">
                <div className="bg-white/70 rounded-lg p-3">
                  <p className="text-sm font-medium text-gray-800">Intensidade</p>
                  <p className="text-xs text-gray-600">
                    {formData.rpe >= 8 ? 'Alta' : formData.rpe >= 6 ? 'Moderada' : 'Baixa'}
                  </p>
                </div>
                <div className="bg-white/70 rounded-lg p-3">
                  <p className="text-sm font-medium text-gray-800">Carga de Treino</p>
                  <p className="text-xs text-gray-600">
                    TRIMP: {formData.trimp} | TSS: {formData.tss}
                  </p>
                </div>
                <div className="bg-white/70 rounded-lg p-3">
                  <p className="text-sm font-medium text-gray-800">Status</p>
                  <p className="text-xs text-gray-600">
                    {tsb > 5 ? 'Pronto para treino intenso' : tsb > 0 ? 'Equilibrado' : 'Necessita recuperação'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrainingPage;