// [AI Generated] Data: 04/01/2025
// Descrição: Página de Avaliação de Reabilitação Física com escalas NRS, PSFS, HADS, EARS e Barthel
// Gerado por: Cursor AI
// Versão: React 18.3.1, TypeScript 5.5.3
// AI_GENERATED_CODE_START
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, ClipboardList, AlertCircle, CheckCircle, Plus, Trash2, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, BarChart, Bar, Tooltip } from 'recharts';
import { CustomTooltip } from '../utils/dataUtils';

interface RehabilitationAssessmentPageProps {
  userEmail: string | null;
}

interface PSFSTask {
  id: string;
  description: string;
  difficulty: number;
}

interface AssessmentData {
  nrs: number; // 0-10
  psfs: PSFSTask[]; // até 5 tarefas
  hads: {
    anxiety: number[]; // 7 questões (0-3 cada)
    depression: number[]; // 7 questões (0-3 cada)
  };
  ears: number[]; // 6 questões (0-4 cada)
  barthel: number[]; // 10 itens (0-15 pontos cada, variável)
  timestamp: string;
}

const RehabilitationAssessmentPage: React.FC<RehabilitationAssessmentPageProps> = ({ userEmail }) => {
  const navigate = useNavigate();
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [activeTab, setActiveTab] = useState<'nrs' | 'psfs' | 'hads' | 'ears' | 'barthel'>('nrs');

  const [assessmentData, setAssessmentData] = useState<AssessmentData>({
    nrs: 0,
    psfs: [],
    hads: {
      anxiety: [0, 0, 0, 0, 0, 0, 0],
      depression: [0, 0, 0, 0, 0, 0, 0]
    },
    ears: [0, 0, 0, 0, 0, 0],
    barthel: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    timestamp: new Date().toISOString()
  });

  // Carregar dados salvos
  useEffect(() => {
    const loadSavedData = () => {
      try {
        const savedData = localStorage.getItem(`rehabilitation_assessment_${userEmail}`);
        if (savedData) {
          const parsedData = JSON.parse(savedData);
          setAssessmentData(parsedData);
        }
      } catch (error) {
        console.error('Erro ao carregar dados salvos:', error);
      }
    };

    if (userEmail) {
      loadSavedData();
    }
  }, [userEmail]);

  // Questões HADS
  const hadsQuestions = {
    anxiety: [
      "Eu me sinto tenso ou contraído",
      "Eu sinto uma espécie de medo, como se alguma coisa ruim fosse acontecer",
      "Estou com a cabeça cheia de preocupações",
      "Consigo ficar sentado à vontade e me sentir relaxado",
      "Eu sinto uma espécie de medo, como um frio na barriga ou um aperto no estômago",
      "Eu me sinto inquieto, como se eu não pudesse ficar parado em lugar nenhum",
      "Eu sinto medo, como se algo terrível fosse acontecer"
    ],
    depression: [
      "Eu ainda sinto gosto pelas mesmas coisas de antes",
      "Eu dou risada e me divirto quando vejo coisas engraçadas",
      "Eu me sinto alegre",
      "Eu me sinto lento para pensar e fazer as coisas",
      "Eu perdi o interesse em cuidar da minha aparência",
      "Eu me sinto animado para fazer coisas",
      "Eu consigo sentir prazer quando assisto a um bom programa de TV, de rádio ou quando leio alguma coisa"
    ]
  };

  // Questões EARS
  const earsQuestions = [
    "Eu sigo as instruções do meu fisioterapeuta/médico",
    "Eu faço os exercícios prescritos regularmente",
    "Eu compareço às consultas marcadas",
    "Eu sigo as recomendações sobre atividades diárias",
    "Eu tomo os medicamentos conforme prescrito",
    "Eu mantenho um estilo de vida saudável conforme orientado"
  ];

  // Itens Barthel
  const barthelItems = [
    { name: "Alimentação", maxScore: 10 },
    { name: "Banho", maxScore: 5 },
    { name: "Cuidados pessoais", maxScore: 5 },
    { name: "Vestir-se", maxScore: 10 },
    { name: "Intestino", maxScore: 10 },
    { name: "Bexiga", maxScore: 10 },
    { name: "Uso do banheiro", maxScore: 10 },
    { name: "Transferência", maxScore: 15 },
    { name: "Mobilidade", maxScore: 15 },
    { name: "Escadas", maxScore: 10 }
  ];

  const handleNRSChange = (value: number) => {
    setAssessmentData(prev => ({
      ...prev,
      nrs: value,
      timestamp: new Date().toISOString()
    }));
  };

  const addPSFSTask = () => {
    if (assessmentData.psfs.length < 5) {
      const newTask: PSFSTask = {
        id: Date.now().toString(),
        description: '',
        difficulty: 0
      };
      setAssessmentData(prev => ({
        ...prev,
        psfs: [...prev.psfs, newTask],
        timestamp: new Date().toISOString()
      }));
    }
  };

  const updatePSFSTask = (id: string, field: 'description' | 'difficulty', value: string | number) => {
    setAssessmentData(prev => ({
      ...prev,
      psfs: prev.psfs.map(task => 
        task.id === id ? { ...task, [field]: value } : task
      ),
      timestamp: new Date().toISOString()
    }));
  };

  const removePSFSTask = (id: string) => {
    setAssessmentData(prev => ({
      ...prev,
      psfs: prev.psfs.filter(task => task.id !== id),
      timestamp: new Date().toISOString()
    }));
  };

  const handleHADSChange = (type: 'anxiety' | 'depression', index: number, value: number) => {
    setAssessmentData(prev => ({
      ...prev,
      hads: {
        ...prev.hads,
        [type]: prev.hads[type].map((score, i) => i === index ? value : score)
      },
      timestamp: new Date().toISOString()
    }));
  };

  const handleEARSChange = (index: number, value: number) => {
    setAssessmentData(prev => ({
      ...prev,
      ears: prev.ears.map((score, i) => i === index ? value : score),
      timestamp: new Date().toISOString()
    }));
  };

  const handleBarthelChange = (index: number, value: number) => {
    setAssessmentData(prev => ({
      ...prev,
      barthel: prev.barthel.map((score, i) => i === index ? value : score),
      timestamp: new Date().toISOString()
    }));
  };

  const calculateScores = () => {
    const hadsAnxietyScore = assessmentData.hads.anxiety.reduce((sum, score) => sum + score, 0);
    const hadsDepressionScore = assessmentData.hads.depression.reduce((sum, score) => sum + score, 0);
    const earsScore = assessmentData.ears.reduce((sum, score) => sum + score, 0);
    const barthelScore = assessmentData.barthel.reduce((sum, score) => sum + score, 0);
    const psfsAverage = assessmentData.psfs.length > 0 
      ? assessmentData.psfs.reduce((sum, task) => sum + task.difficulty, 0) / assessmentData.psfs.length 
      : 0;

    return {
      nrs: assessmentData.nrs,
      psfsAverage: psfsAverage.toFixed(1),
      hadsAnxiety: hadsAnxietyScore,
      hadsDepression: hadsDepressionScore,
      ears: earsScore,
      barthel: barthelScore
    };
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveStatus('idle');

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      localStorage.setItem(`rehabilitation_assessment_${userEmail}`, JSON.stringify(assessmentData));
      
      // Salvar histórico
      const historyKey = `rehabilitation_assessment_history_${userEmail}`;
      const existingHistory = JSON.parse(localStorage.getItem(historyKey) || '[]');
      const newEntry = {
        ...assessmentData,
        scores: calculateScores(),
        date: new Date().toLocaleDateString('pt-BR')
      };
      
      const updatedHistory = [newEntry, ...existingHistory.slice(0, 29)];
      localStorage.setItem(historyKey, JSON.stringify(updatedHistory));
      
      console.log('Avaliação salva com sucesso:', assessmentData);
      setSaveStatus('success');
      
      setTimeout(() => {
        setSaveStatus('idle');
      }, 3000);
      
    } catch (error) {
      console.error('Erro ao salvar avaliação:', error);
      setSaveStatus('error');
      
      setTimeout(() => {
        setSaveStatus('idle');
      }, 3000);
    } finally {
      setIsSaving(false);
    }
  };

  const scores = calculateScores();

  // Dados para gráfico de evolução
  const evolutionData = [
    { name: 'NRS', value: scores.nrs, max: 10 },
    { name: 'PSFS', value: parseFloat(scores.psfsAverage), max: 10 },
    { name: 'HADS-A', value: scores.hadsAnxiety, max: 21 },
    { name: 'HADS-D', value: scores.hadsDepression, max: 21 },
    { name: 'EARS', value: scores.ears, max: 24 },
    { name: 'Barthel', value: scores.barthel, max: 100 }
  ];

  const tabs = [
    { id: 'nrs', label: 'NRS (Dor)', icon: AlertCircle },
    { id: 'psfs', label: 'PSFS (Função)', icon: ClipboardList },
    { id: 'hads', label: 'HADS (Humor)', icon: TrendingUp },
    { id: 'ears', label: 'EARS (Adesão)', icon: CheckCircle },
    { id: 'barthel', label: 'Barthel (Função)', icon: ClipboardList }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 p-2 md:p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-4 md:mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="p-2 rounded-lg bg-white shadow-md hover:shadow-lg transition-shadow"
              >
                <ArrowLeft className="h-5 w-5 text-gray-600" />
              </button>
              <div>
                <h1 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">
                  Avaliação de Reabilitação Física
                </h1>
                <p className="text-sm md:text-base text-gray-600">
                  Escalas padronizadas para avaliação funcional e evolução
                </p>
              </div>
            </div>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                saveStatus === 'success' 
                  ? 'bg-green-600 text-white' 
                  : saveStatus === 'error'
                  ? 'bg-red-600 text-white'
                  : 'bg-purple-600 text-white hover:bg-purple-700'
              } ${isSaving ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isSaving ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : saveStatus === 'success' ? (
                <CheckCircle className="h-4 w-4" />
              ) : saveStatus === 'error' ? (
                <AlertCircle className="h-4 w-4" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              <span className="hidden md:inline">
                {isSaving ? 'Salvando...' : saveStatus === 'success' ? 'Salvo!' : saveStatus === 'error' ? 'Erro' : 'Salvar'}
              </span>
            </button>
          </div>
        </div>

        {/* Status de Salvamento */}
        {saveStatus !== 'idle' && (
          <div className={`mb-4 p-3 rounded-lg ${
            saveStatus === 'success' ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
          }`}>
            <div className="flex items-center space-x-2">
              {saveStatus === 'success' ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-600" />
              )}
              <span className={`text-sm font-medium ${
                saveStatus === 'success' ? 'text-green-800' : 'text-red-800'
              }`}>
                {saveStatus === 'success' 
                  ? 'Avaliação salva com sucesso!' 
                  : 'Erro ao salvar avaliação. Tente novamente.'}
              </span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 md:gap-6">
          {/* Navegação das Escalas */}
          <div className="lg:col-span-3 space-y-4">
            <div className="bg-white rounded-xl shadow-lg p-4">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">Escalas de Avaliação</h2>
              <div className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 ${
                        activeTab === tab.id
                          ? 'bg-purple-50 text-purple-700 border-2 border-purple-200'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <Icon className={`h-5 w-5 ${activeTab === tab.id ? 'text-purple-600' : 'text-gray-400'}`} />
                      <span className="font-medium text-sm">{tab.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Resumo dos Scores */}
            <div className="bg-white rounded-xl shadow-lg p-4">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Scores Atuais</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">NRS (Dor)</span>
                  <span className="font-semibold text-red-600">{scores.nrs}/10</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">PSFS (Função)</span>
                  <span className="font-semibold text-blue-600">{scores.psfsAverage}/10</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">HADS Ansiedade</span>
                  <span className="font-semibold text-yellow-600">{scores.hadsAnxiety}/21</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">HADS Depressão</span>
                  <span className="font-semibold text-orange-600">{scores.hadsDepression}/21</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">EARS (Adesão)</span>
                  <span className="font-semibold text-green-600">{scores.ears}/24</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Barthel</span>
                  <span className="font-semibold text-purple-600">{scores.barthel}/100</span>
                </div>
              </div>
            </div>
          </div>

          {/* Conteúdo Principal */}
          <div className="lg:col-span-9 space-y-6">
            {/* NRS - Escala Numérica de Dor */}
            {activeTab === 'nrs' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <AlertCircle className="mr-2 h-6 w-6 text-red-600" />
                  NRS - Escala Numérica de Dor
                </h2>
                <p className="text-gray-600 mb-6">
                  Avalie sua dor atual em uma escala de 0 a 10, onde 0 = sem dor e 10 = pior dor imaginável.
                </p>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nível de Dor Atual
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={assessmentData.nrs}
                      onChange={(e) => handleNRSChange(parseInt(e.target.value))}
                      className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-sm text-gray-500 mt-2">
                      <span>0 - Sem dor</span>
                      <span className="font-bold text-red-600 text-lg">{assessmentData.nrs}/10</span>
                      <span>10 - Pior dor</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-11 gap-1 mt-4">
                    {[...Array(11)].map((_, i) => (
                      <button
                        key={i}
                        onClick={() => handleNRSChange(i)}
                        className={`h-12 rounded-lg border-2 font-semibold transition-colors ${
                          assessmentData.nrs === i
                            ? 'bg-red-600 text-white border-red-600'
                            : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
                        }`}
                      >
                        {i}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* PSFS - Patient-Specific Functional Scale */}
            {activeTab === 'psfs' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-gray-800 flex items-center">
                    <ClipboardList className="mr-2 h-6 w-6 text-blue-600" />
                    PSFS - Escala Funcional Específica do Paciente
                  </h2>
                  <button
                    onClick={addPSFSTask}
                    disabled={assessmentData.psfs.length >= 5}
                    className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Adicionar Tarefa</span>
                  </button>
                </div>
                
                <p className="text-gray-600 mb-6">
                  Liste até 5 atividades que você tem dificuldade para realizar e avalie o nível de dificuldade (0 = impossível, 10 = sem dificuldade).
                </p>

                <div className="space-y-4">
                  {assessmentData.psfs.map((task, index) => (
                    <div key={task.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium text-gray-800">Atividade {index + 1}</h4>
                        <button
                          onClick={() => removePSFSTask(task.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Descrição da Atividade
                          </label>
                          <input
                            type="text"
                            value={task.description}
                            onChange={(e) => updatePSFSTask(task.id, 'description', e.target.value)}
                            placeholder="Ex: Subir escadas, carregar compras..."
                            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Nível de Dificuldade: {task.difficulty}/10
                          </label>
                          <input
                            type="range"
                            min="0"
                            max="10"
                            value={task.difficulty}
                            onChange={(e) => updatePSFSTask(task.id, 'difficulty', parseInt(e.target.value))}
                            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                          />
                          <div className="flex justify-between text-xs text-gray-500 mt-1">
                            <span>Impossível</span>
                            <span>Sem dificuldade</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {assessmentData.psfs.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <ClipboardList className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>Nenhuma atividade adicionada ainda.</p>
                      <p className="text-sm">Clique em "Adicionar Tarefa" para começar.</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* HADS - Hospital Anxiety and Depression Scale */}
            {activeTab === 'hads' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <TrendingUp className="mr-2 h-6 w-6 text-yellow-600" />
                  HADS - Escala Hospitalar de Ansiedade e Depressão
                </h2>
                <p className="text-gray-600 mb-6">
                  Para cada item, marque a resposta que melhor corresponde ao que você tem sentido na última semana.
                </p>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Ansiedade */}
                  <div>
                    <h3 className="text-lg font-semibold text-yellow-600 mb-4">Ansiedade</h3>
                    <div className="space-y-4">
                      {hadsQuestions.anxiety.map((question, index) => (
                        <div key={index} className="border border-gray-200 rounded-lg p-4">
                          <p className="text-sm font-medium text-gray-800 mb-3">{question}</p>
                          <div className="grid grid-cols-4 gap-2">
                            {['Nunca', 'Às vezes', 'Muitas vezes', 'Sempre'].map((option, optionIndex) => (
                              <button
                                key={optionIndex}
                                onClick={() => handleHADSChange('anxiety', index, optionIndex)}
                                className={`p-2 text-xs rounded-lg border transition-colors ${
                                  assessmentData.hads.anxiety[index] === optionIndex
                                    ? 'bg-yellow-600 text-white border-yellow-600'
                                    : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
                                }`}
                              >
                                {option}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Depressão */}
                  <div>
                    <h3 className="text-lg font-semibold text-orange-600 mb-4">Depressão</h3>
                    <div className="space-y-4">
                      {hadsQuestions.depression.map((question, index) => (
                        <div key={index} className="border border-gray-200 rounded-lg p-4">
                          <p className="text-sm font-medium text-gray-800 mb-3">{question}</p>
                          <div className="grid grid-cols-4 gap-2">
                            {['Nunca', 'Às vezes', 'Muitas vezes', 'Sempre'].map((option, optionIndex) => (
                              <button
                                key={optionIndex}
                                onClick={() => handleHADSChange('depression', index, optionIndex)}
                                className={`p-2 text-xs rounded-lg border transition-colors ${
                                  assessmentData.hads.depression[index] === optionIndex
                                    ? 'bg-orange-600 text-white border-orange-600'
                                    : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
                                }`}
                              >
                                {option}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* EARS - Exercise Adherence Rating Scale */}
            {activeTab === 'ears' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <CheckCircle className="mr-2 h-6 w-6 text-green-600" />
                  EARS - Escala de Adesão ao Exercício
                </h2>
                <p className="text-gray-600 mb-6">
                  Avalie com que frequência você segue as orientações do seu tratamento (0 = nunca, 4 = sempre).
                </p>

                <div className="space-y-4">
                  {earsQuestions.map((question, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <p className="text-sm font-medium text-gray-800 mb-3">{question}</p>
                      <div className="grid grid-cols-5 gap-2">
                        {['Nunca', 'Raramente', 'Às vezes', 'Frequentemente', 'Sempre'].map((option, optionIndex) => (
                          <button
                            key={optionIndex}
                            onClick={() => handleEARSChange(index, optionIndex)}
                            className={`p-2 text-xs rounded-lg border transition-colors ${
                              assessmentData.ears[index] === optionIndex
                                ? 'bg-green-600 text-white border-green-600'
                                : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
                            }`}
                          >
                            {option}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Barthel Index */}
            {activeTab === 'barthel' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <ClipboardList className="mr-2 h-6 w-6 text-purple-600" />
                  Índice de Barthel - Atividades de Vida Diária
                </h2>
                <p className="text-gray-600 mb-6">
                  Avalie seu nível de independência para realizar as atividades básicas do dia a dia.
                </p>

                <div className="space-y-4">
                  {barthelItems.map((item, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium text-gray-800">{item.name}</h4>
                        <span className="text-sm text-gray-500">
                          {assessmentData.barthel[index]}/{item.maxScore} pontos
                        </span>
                      </div>
                      
                      <input
                        type="range"
                        min="0"
                        max={item.maxScore}
                        step={item.maxScore === 5 ? 5 : item.maxScore === 10 ? 5 : 5}
                        value={assessmentData.barthel[index]}
                        onChange={(e) => handleBarthelChange(index, parseInt(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                      />
                      
                      <div className="flex justify-between text-xs text-gray-500 mt-2">
                        <span>Dependente</span>
                        <span>Independente</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Gráfico de Evolução */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Resumo das Avaliações</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={evolutionData}>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="value" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RehabilitationAssessmentPage;
// AI_GENERATED_CODE_END