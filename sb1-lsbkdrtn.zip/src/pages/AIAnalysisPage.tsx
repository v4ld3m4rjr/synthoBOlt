import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Brain, TrendingUp, AlertTriangle, Lightbulb, Activity, Heart, Moon } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { generateMockData } from '../utils/dataUtils';

const AIAnalysisPage: React.FC = () => {
  const navigate = useNavigate();
  const [selectedAnalysis, setSelectedAnalysis] = useState<string>('overview');

  const analysisData = generateMockData(7);
  
  const physiologicalData = [
    { subject: 'Recuperação', A: 7.2, B: 6.8, fullMark: 10 },
    { subject: 'Energia', A: 6.8, B: 7.1, fullMark: 10 },
    { subject: 'Estresse', A: 4.3, B: 5.2, fullMark: 10 },
    { subject: 'Sono', A: 7.9, B: 6.5, fullMark: 10 },
    { subject: 'Humor', A: 8.1, B: 7.3, fullMark: 10 },
    { subject: 'Foco', A: 6.5, B: 6.9, fullMark: 10 },
  ];

  const analyses = {
    overview: {
      title: 'Visão Geral Fisiológica',
      icon: Brain,
      color: 'text-purple-600',
      content: `Com base nos dados dos últimos 7 dias, seu sistema nervoso apresenta sinais de adaptação positiva. 
      A variabilidade da frequência cardíaca indica uma boa capacidade de recuperação, enquanto os níveis de cortisol 
      sugerem um estresse controlado. O padrão de sono REM está otimizado, favorecendo a consolidação da memória e 
      recuperação neuromuscular.`,
      recommendations: [
        'Mantenha a consistência no horário de sono',
        'Considere técnicas de respiração para otimizar o sistema parassimpático',
        'Monitore os níveis de hidratação para manter a função cognitiva'
      ]
    },
    recovery: {
      title: 'Análise de Recuperação',
      icon: Heart,
      color: 'text-green-600',
      content: `Seu processo de recuperação está funcionando adequadamente. A síntese proteica pós-treino está 
      otimizada, evidenciada pelos marcadores de recuperação. O balanço entre carga e recuperação sugere que 
      você está na zona ideal para adaptações positivas sem overreaching.`,
      recommendations: [
        'Aumente a ingestão de proteínas nas 2h pós-treino',
        'Priorize 7-9 horas de sono de qualidade',
        'Considere banhos de contraste para acelerar a recuperação'
      ]
    },
    stress: {
      title: 'Resposta ao Estresse',
      icon: AlertTriangle,
      color: 'text-red-600',
      content: `Os níveis de estresse estão ligeiramente elevados, indicando ativação do eixo hipotálamo-hipófise-adrenal. 
      Isso pode afetar a capacidade de recuperação e a qualidade do sono. É importante implementar estratégias 
      de gerenciamento do estresse para manter o equilíbrio hormonal.`,
      recommendations: [
        'Implemente técnicas de mindfulness diariamente',
        'Reduza a intensidade dos treinos por 2-3 dias',
        'Considere suplementação com magnésio e ashwagandha'
      ]
    },
    sleep: {
      title: 'Arquitetura do Sono',
      icon: Moon,
      color: 'text-blue-600',
      content: `A arquitetura do seu sono apresenta boa distribuição entre as fases, com destaque para o sono de ondas 
      lentas (estágio 3), essencial para a recuperação física. O tempo de latência indica eficiência no início 
      do sono, sugerindo um ritmo circadiano bem regulado.`,
      recommendations: [
        'Mantenha o ambiente escuro e fresco (18-20°C)',
        'Evite telas 2h antes de dormir',
        'Considere melatonina se houver dificuldade para adormecer'
      ]
    }
  };

  const currentAnalysis = analyses[selectedAnalysis as keyof typeof analyses];
  const Icon = currentAnalysis.icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-lg bg-white shadow-md hover:shadow-lg transition-shadow"
            >
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Análise Neurofisiológica</h1>
              <p className="text-gray-600">Insights baseados em IA sobre seu estado fisiológico</p>
            </div>
          </div>
          <div className="flex items-center space-x-2 bg-white rounded-lg px-3 py-2 shadow-md">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-sm font-medium text-gray-600">IA Ativa</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Navegação das Análises */}
          <div className="lg:col-span-3 space-y-4">
            {Object.entries(analyses).map(([key, analysis]) => {
              const AnalysisIcon = analysis.icon;
              return (
                <button
                  key={key}
                  onClick={() => setSelectedAnalysis(key)}
                  className={`w-full p-4 rounded-xl text-left transition-all duration-200 ${
                    selectedAnalysis === key
                      ? 'bg-white shadow-lg border-2 border-purple-200'
                      : 'bg-white/70 hover:bg-white hover:shadow-md'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <AnalysisIcon className={`h-5 w-5 ${analysis.color}`} />
                    <div>
                      <h3 className="font-semibold text-gray-800">{analysis.title}</h3>
                      <p className="text-xs text-gray-500">Clique para ver detalhes</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Análise Principal */}
          <div className="lg:col-span-9 space-y-6">
            {/* Conteúdo da Análise */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center space-x-3 mb-6">
                <Icon className={`h-6 w-6 ${currentAnalysis.color}`} />
                <h2 className="text-xl font-semibold text-gray-800">{currentAnalysis.title}</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  {currentAnalysis.content}
                </p>

                <div className="bg-blue-50 rounded-lg p-4 mb-6">
                  <h3 className="flex items-center text-lg font-semibold text-blue-800 mb-3">
                    <Lightbulb className="h-5 w-5 mr-2" />
                    Recomendações Personalizadas
                  </h3>
                  <ul className="space-y-2">
                    {currentAnalysis.recommendations.map((rec, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0" />
                        <span className="text-blue-700">{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Gráficos de Suporte */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Tendência Temporal */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                  <TrendingUp className="mr-2 h-5 w-5 text-purple-600" />
                  Tendência dos Últimos 7 Dias
                </h3>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={analysisData}>
                      <XAxis dataKey="date" hide />
                      <YAxis domain={[0, 10]} hide />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#8B5CF6"
                        strokeWidth={2}
                        dot={{ fill: '#8B5CF6', r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Comparação Estado Atual vs Ideal */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                  <Activity className="mr-2 h-5 w-5 text-green-600" />
                  Atual vs Ideal
                </h3>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={physiologicalData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10 }} />
                      <PolarRadiusAxis angle={90} domain={[0, 10]} tick={{ fontSize: 8 }} />
                      <Radar
                        name="Atual"
                        dataKey="A"
                        stroke="#8B5CF6"
                        fill="#8B5CF6"
                        fillOpacity={0.3}
                        strokeWidth={2}
                      />
                      <Radar
                        name="Ideal"
                        dataKey="B"
                        stroke="#10B981"
                        fill="#10B981"
                        fillOpacity={0.1}
                        strokeWidth={2}
                        strokeDasharray="5,5"
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Insights Adicionais */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Insights Neurofisiológicos Adicionais
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-green-50 rounded-lg p-4">
                  <h4 className="font-semibold text-green-800 mb-2">Sistema Nervoso</h4>
                  <p className="text-sm text-green-700">
                    Balanço autonômico adequado. Dominância parassimpática em repouso indicando boa capacidade de recuperação.
                  </p>
                </div>
                <div className="bg-blue-50 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-800 mb-2">Metabolismo</h4>
                  <p className="text-sm text-blue-700">
                    Eficiência metabólica otimizada. Boa utilização de substratos energéticos durante o exercício.
                  </p>
                </div>
                <div className="bg-purple-50 rounded-lg p-4">
                  <h4 className="font-semibold text-purple-800 mb-2">Adaptação</h4>
                  <p className="text-sm text-purple-700">
                    Processo de adaptação em curso. Marcadores indicam supercompensação adequada ao estímulo de treino.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAnalysisPage;